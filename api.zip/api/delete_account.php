<?php
// Start output buffering
ob_start();

// Include required files
require_once 'cors.php';
require_once 'db_connect.php';

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Start session
session_start();

// Function to send JSON response
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['error' => 'Not logged in'], 401);
    }

    // Check if it's a POST request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        send_json_response(['error' => 'Method not allowed'], 405);
    }

    // Get user ID from session
    $user_id = $_SESSION['user_id'];
    $first_name = $_SESSION['first_name'];

    // Start transaction
    $pdo->beginTransaction();

    try {

        $stmt = $pdo->prepare("DELETE FROM track_parcels WHERE user_id = :user_id");
$stmt->execute([':user_id' => $user_id]);

        // Delete user's orders
        $stmt = $pdo->prepare("DELETE FROM users_orders WHERE user_id = :user_id");
        $stmt->execute([':user_id' => $user_id]);

        // Delete user's activity
        $stmt = $pdo->prepare("DELETE FROM users_activity WHERE user_id = :user_id");
        $stmt->execute([':user_id' => $user_id]);

        // Delete user's saved locations
        

        // Delete user's account
        $stmt = $pdo->prepare("DELETE FROM users WHERE first_name = :first_name");
        $stmt->execute([':first_name' => $first_name]);

        // Commit transaction
        $pdo->commit();

        // Destroy session
        session_destroy();

        send_json_response([
            'success' => true,
            'message' => 'Account deleted successfully'
        ]);

    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        throw $e;
    }

} catch (Exception $e) {
    error_log("Error in delete_account.php: " . $e->getMessage());
    send_json_response(['error' => 'An internal server error occurred'], 500);
}

// End output buffering
ob_end_flush();
?> 