<?php
// polling_worker.php: Polls for new orders and runs the drone simulation worker automatically.

// --- CONFIG ---
function haversineDistance($from, $to) {
    list($lat1, $lng1) = explode(',', $from);
    list($lat2, $lng2) = explode(',', $to);
    $earthRadius = 6371; // km
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng/2) * sin($dLng/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $earthRadius * $c; // in km
}

$phpPath = 'C:\\xampp\\php\\php.exe';
$workerScript = __DIR__ . '\\simulate_drone_worker.php';
$pollIntervalSeconds = 30; // How often to poll for new orders
$delivery_mode = 'real'; 
$drone_speed_kmh = 36;

require_once __DIR__ . '/db_connect.php';

// Infinite loop (can be stopped by Task Scheduler or manually)
while (true) {
    try {
        // Find all orders with status 'pending' and not yet processed (add a processed flag or use a queue table for production)
        $stmt = $pdo->prepare("SELECT order_id FROM users_orders WHERE order_status = 'pending' AND (last_simulated IS NULL OR last_simulated = 0) ORDER BY created_at DESC LIMIT 3");        $stmt->execute();
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($orders as $order) {
            $orderId = $order['order_id'];
            // Mark as processing to avoid duplicate runs
            $update = $pdo->prepare("UPDATE users_orders SET last_simulated = 1 WHERE order_id = ?");
            $update->execute([$orderId]);

            // Fetch order coordinates for ETA calculation
            $stmtOrder = $pdo->prepare("SELECT pickup_lat, pickup_lng, delivery_lat, delivery_lng FROM users_orders WHERE order_id = ?");
            $stmtOrder->execute([$orderId]);
            $coords = $stmtOrder->fetch(PDO::FETCH_ASSOC);
            if ($coords && !empty($coords['pickup_lat']) && !empty($coords['pickup_lng']) && !empty($coords['delivery_lat']) && !empty($coords['delivery_lng'])) {
                $from = $coords['pickup_lat'] . ',' . $coords['pickup_lng'];
                $to = $coords['delivery_lat'] . ',' . $coords['delivery_lng'];
            } else {
                $from = '28.6139,77.2090';
                $to = '28.7041,77.1025';
            }
            $distance_km = haversineDistance($from, $to);
            $eta_minutes = ($distance_km / $drone_speed_kmh) * 60;
            if ($delivery_mode === 'real') {
                $stepsToPickup = 6;
                $stepsToDestination = max(1, ceil($eta_minutes / 0.5)); // 30s per step
                $stepSleep = 30;
            } else {
                $stepsToPickup = 6;
                $stepsToDestination = 24;
                $stepSleep = 3;
            }
            $orderIdEscaped = escapeshellarg($orderId);
            $cmd = 'start /B "" "' . $phpPath . '" "' . $workerScript . '" ' . $orderIdEscaped . ' ' . $delivery_mode . ' ' . $stepsToPickup . ' ' . $stepsToDestination . ' ' . $stepSleep . ' > NUL 2>&1';
            file_put_contents(__DIR__ . '/order_creation.log', "[" . date('Y-m-d H:i:s') . "] Polling worker command: $cmd\n", FILE_APPEND);
            exec($cmd);
        }
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/order_creation.log', "[" . date('Y-m-d H:i:s') . "] Polling worker error: " . $e->getMessage() . "\n", FILE_APPEND);
    }
    sleep($pollIntervalSeconds);
}
