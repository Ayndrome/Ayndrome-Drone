<?php
require '../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendOrderConfirmationEmail($userEmail, $userName, $orderDetails) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'shashanksaket9@gmail.com';
        $mail->Password = 'goou gtms okin wdwx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('shashanksaket9@gmail.com', 'Ayndrome Delivery');
        $mail->addAddress($userEmail, $userName);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Order Confirmation - Ayndrome Delivery';

        // Email body
        $body = "
        <html>
        <head>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 640px;
                    margin: 40px auto;
                    background: #ffffff;
                    border-radius: 10px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                    overflow: hidden;
                }
                .header {
                    background: rgb(0,51,102);
background: linear-gradient(159deg, rgba(0,51,102,1) 0%, rgba(15,82,186,1) 100%);
                    color: #fff;
                    padding: 30px 20px;
                    text-align: center;
                }
                .header h2 {
                    margin: 0;
                    font-size: 28px;
                }
                .content {
                    padding: 30px 20px;
                    color: #333;
                }
                .order-details {
                    margin-top: 20px;
                    background-color: #f9f9f9;
                    padding: 20px;
                    border-left: 4px solid #8E2DE2;
                    border-radius: 5px;
                }
                .order-details p {
                    margin: 8px 0;
                    line-height: 1.5;
                }
                .cta-button {
                    display: inline-block;
                    margin-top: 25px;
                    padding: 12px 24px;
                    background: rgb(0,51,102);
background: linear-gradient(159deg, rgba(0,51,102,1) 0%, rgba(15,82,186,1) 100%);
                    color: #fff !important;
                    text-decoration: none;
                    border-radius: 5px;
                    font-weight: bold;
                    transition: background-color 0.3s ease;
                }
                .cta-button:hover {
background: rgb(0,51,102);
background: linear-gradient(159deg, rgba(0,51,102,1) 0%, rgba(15,82,186,1) 100%);
                }
                .footer {
                    text-align: center;
                    font-size: 12px;
                    color: #777;
                    padding: 20px;
                    background-color: #fafafa;
                }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>🛒 Order Confirmation</h2>
                </div>
                <div class='content'>
                    <p>Hi <strong>{$userName}</strong>,</p>
                    <p>Thanks for placing your order with <strong>Ayndrome Delivery</strong>! Here's a summary:</p>
        
                    <div class='order-details'>
                        <p><strong>Order ID:</strong> {$orderDetails['order_id']}</p>
                        <p><strong>Pickup Address:</strong> {$orderDetails['pickup_address']}</p>
                        <p><strong>Delivery Address:</strong> {$orderDetails['delivery_address']}</p>
                        <p><strong>Scheduled Date:</strong> {$orderDetails['scheduled_date']}</p>
                        <p><strong>Scheduled Time:</strong> {$orderDetails['scheduled_time']}</p>
                        <p><strong>Package Dimensions:</strong> {$orderDetails['package_dimensions']}</p>
                        <p><strong>Total Amount:</strong> ₹{$orderDetails['total_amount']}</p>
                        <p><strong>Status:</strong> <span style='color: green;'>{$orderDetails['status']}</span></p>
                    </div>
        
                    <a href='https://ayndrome.com/track-order/{$orderDetails['order_id']}' class='cta-button'>
                        Track Your Order
                    </a>
        
                    <p style='margin-top: 30px;'>Need help? Just reply to this email or <a href='https://yourdomain.com/support'>contact support</a>.</p>
                </div>
                <div class='footer'>
                    <p>This is an automated email. Please do not reply.</p>
                    <p>&copy; " . date('Y') . " Ayndrome Delivery. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";
        

        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email sending failed: " . $mail->ErrorInfo);
        return false;
    }
}
?> 