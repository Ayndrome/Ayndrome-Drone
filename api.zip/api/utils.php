<?php
// Check if function already exists
if (!function_exists('send_json_response')) {
    // Function to send JSON response
    function send_json_response($data, $status_code = 200) {
        http_response_code($status_code);
        echo json_encode($data);
        exit;
    }
}
?> 