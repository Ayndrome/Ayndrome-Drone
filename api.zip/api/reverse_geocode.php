<?php
header('Content-Type: application/json');
// Allow CORS for local development (adjust for production)
header('Access-Control-Allow-Origin: *');

if (!isset($_GET['lat']) || !isset($_GET['lng'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing coordinates']);
    exit;
}
$lat = $_GET['lat'];
$lng = $_GET['lng'];

// TODO: Replace with your real server-side API key (keep this safe!)
$apiKey = 'AIzaSyA4_u_wM0LenXb_RgSw-n_o5ZXzrmkntz0';
$url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&key=$apiKey";

$response = file_get_contents($url);
if ($response === FALSE) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to contact Google Geocoding API']);
    exit;
}
echo $response;
