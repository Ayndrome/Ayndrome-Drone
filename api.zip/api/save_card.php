<?php
require_once 'db_connect.php';
require_once 'cors.php';
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'User not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['card_number']) || !isset($data['card_holder_name']) || !isset($data['expiry_month']) || !isset($data['expiry_year'])) {
    echo json_encode(['success' => false, 'error' => 'Missing card data']);
    exit;
}

$user_id = $_SESSION['user_id'];
$card_number = preg_replace('/\D/', '', $data['card_number']);
$last4 = substr($card_number, -4);
$card_holder_name = $data['card_holder_name'];
$expiry_month = $data['expiry_month'];
$expiry_year = $data['expiry_year'];
$card_type = 'VISA';

// Check if card already exists for this user
$stmt = $pdo->prepare("SELECT id FROM saved_payment WHERE user_id = :user_id AND last4 = :last4 AND expiry_month = :expiry_month AND expiry_year = :expiry_year");
$stmt->execute([
    ':user_id' => $user_id,
    ':last4' => $last4,
    ':expiry_month' => $expiry_month,
    ':expiry_year' => $expiry_year
]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Card already saved']);
    exit;
}

// Insert new card
$stmt = $pdo->prepare("INSERT INTO saved_payment (user_id, card_holder_name, card_number, expiry_month, expiry_year, card_type, last4) VALUES (:user_id, :card_holder_name, :card_number, :expiry_month, :expiry_year, :card_type, :last4)");
$success = $stmt->execute([
    ':user_id' => $user_id,
    ':card_holder_name' => $card_holder_name,
    ':card_number' => $card_number,
    ':expiry_month' => $expiry_month,
    ':expiry_year' => $expiry_year,
    ':card_type' => $card_type,
    ':last4' => $last4
]);

if ($success) {
    echo json_encode(['success' => true, 'message' => 'Card saved successfully']);
// } else {
//     echo json_encode(['success' => false, 'error' => 'Failed to save card']);
}
