<?php
require_once 'db_connect.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Check database connection
    echo "Checking database connection...\n";
    $pdo->query("SELECT 1");
    echo "Database connection successful\n\n";

    // Check if user is logged in
    session_start();
    if (!isset($_SESSION['user_id'])) {
        echo "User is not logged in\n";
        exit();
    }
    echo "User ID: " . $_SESSION['user_id'] . "\n\n";

    // Check if tables exist
    echo "Checking tables...\n";
    $tables = ['track_parcels', 'users_orders'];
    foreach ($tables as $table) {
        $result = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($result->rowCount() > 0) {
            echo "$table table exists\n";
        } else {
            echo "$table table does NOT exist\n";
        }
    }
    echo "\n";

    // Check if user has any orders
    echo "Checking user orders...\n";
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users_orders WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $orderCount = $stmt->fetchColumn();
    echo "User has $orderCount orders\n\n";

    // Check track_parcels entries
    echo "Checking track_parcels entries...\n";
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM track_parcels tp
        JOIN users_orders uo ON tp.ride_id = uo.id
        WHERE uo.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $trackCount = $stmt->fetchColumn();
    echo "User has $trackCount track_parcels entries\n\n";

    // Try to execute the main query
    echo "Testing main query...\n";
    $query = "
        SELECT 
            tp.tracking_id,
            tp.status,
            tp.progress,
            tp.eta,
            tp.current_location,
            tp.last_updated,
            uo.pickup_address as from_location,
            uo.delivery_address as to_location,
            uo.package_dimensions as items,
            uo.total_amount as cost,
            uo.scheduled_date,
            uo.scheduled_time
        FROM track_parcels tp
        JOIN users_orders uo ON tp.ride_id = uo.id
        WHERE uo.user_id = ?
        ORDER BY tp.last_updated DESC
    ";

    $stmt = $pdo->prepare($query);
    if (!$stmt) {
        throw new Exception('Failed to prepare query: ' . implode(' ', $pdo->errorInfo()));
    }

    $stmt->execute([$_SESSION['user_id']]);
    if ($stmt->errorCode() !== '00000') {
        throw new Exception('Failed to execute query: ' . implode(' ', $stmt->errorInfo()));
    }

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Query executed successfully\n";
    echo "Found " . count($results) . " results\n\n";

    // Display sample data if available
    if (count($results) > 0) {
        echo "Sample data:\n";
        print_r($results[0]);
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Stack trace: " . $e->getTraceAsString() . "\n";
}
?> 