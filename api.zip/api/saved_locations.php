<?php
// Start output buffering
ob_start();

// Start session first
session_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Set content type to JSON
header('Content-Type: application/json');

// Debug information
error_log("Request Origin: " . (isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : 'Not set'));
error_log("Session ID: " . session_id());
error_log("User ID in session: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'Not set'));
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Headers: " . print_r(getallheaders(), true));

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Not logged in'
    ]);
    exit();
}

// Handle different HTTP methods
switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Get user's saved locations
        try {
            $stmt = $conn->prepare("
                SELECT id, name, address, lat, lng, type, is_default, created_at
                FROM saved_locations
                WHERE user_id = ?
                ORDER BY is_default DESC, created_at DESC
            ");
            
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $locations = [];
            while ($row = $result->fetch_assoc()) {
                $locations[] = $row;
            }
            
            echo json_encode([
                'success' => true,
                'locations' => $locations
            ]);
            
        } catch (Exception $e) {
            error_log("Error in saved_locations.php (GET): " . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Failed to fetch saved locations'
            ]);
        }
        break;
        
    case 'POST':
        // Add new saved location
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate required fields
        $requiredFields = ['name', 'address', 'lat', 'lng', 'type'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'error' => "Missing required field: $field"
                ]);
                exit();
            }
        }
        
        try {
            // If this is set as default, unset other defaults
            if (isset($data['is_default']) && $data['is_default']) {
                $stmt = $conn->prepare("
                    UPDATE saved_locations
                    SET is_default = 0
                    WHERE user_id = ? AND is_default = 1
                ");
                $stmt->bind_param("i", $_SESSION['user_id']);
                $stmt->execute();
            }
            
            // Insert new location
            $stmt = $conn->prepare("
                INSERT INTO saved_locations (
                    user_id, name, address, lat, lng, type, is_default
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $isDefault = isset($data['is_default']) ? $data['is_default'] : 0;
            $stmt->bind_param(
                "issddsi",
                $_SESSION['user_id'],
                $data['name'],
                $data['address'],
                $data['lat'],
                $data['lng'],
                $data['type'],
                $isDefault
            );
            
            if ($stmt->execute()) {
                $locationId = $conn->insert_id;
                echo json_encode([
                    'success' => true,
                    'message' => 'Location saved successfully',
                    'location_id' => $locationId
                ]);
            } else {
                throw new Exception("Error saving location: " . $stmt->error);
            }
            
        } catch (Exception $e) {
            error_log("Error in saved_locations.php (POST): " . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Failed to save location'
            ]);
        }
        break;
        
    case 'DELETE':
        // Delete saved location
        $locationId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        
        if (!$locationId) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => 'Location ID is required'
            ]);
            exit();
        }
        
        try {
            $stmt = $conn->prepare("
                DELETE FROM saved_locations
                WHERE id = ? AND user_id = ?
            ");
            
            $stmt->bind_param("ii", $locationId, $_SESSION['user_id']);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Location deleted successfully'
                ]);
            } else {
                throw new Exception("Error deleting location: " . $stmt->error);
            }
            
        } catch (Exception $e) {
            error_log("Error in saved_locations.php (DELETE): " . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Failed to delete location'
            ]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'error' => 'Method not allowed'
        ]);
        break;
}

// End output buffering and flush
ob_end_flush();
?> 