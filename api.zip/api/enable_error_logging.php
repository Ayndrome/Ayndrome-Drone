<?php
// Enable all error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/php/logs/php_error.log');

// Test error logging
error_log("Test error message from enable_error_logging.php");

// Show current PHP configuration
echo "<h2>PHP Error Configuration</h2>";
echo "<pre>";
echo "error_reporting: " . ini_get('error_reporting') . "\n";
echo "display_errors: " . ini_get('display_errors') . "\n";
echo "log_errors: " . ini_get('log_errors') . "\n";
echo "error_log: " . ini_get('error_log') . "\n";
echo "</pre>";

// Create error log file if it doesn't exist
$logFile = 'C:/xampp/php/logs/php_error.log';
if (!file_exists($logFile)) {
    if (touch($logFile)) {
        echo "Created error log file at: $logFile\n";
    } else {
        echo "Failed to create error log file\n";
    }
}

// Check file permissions
if (file_exists($logFile)) {
    echo "<h2>File Permissions</h2>";
    echo "<pre>";
    echo "File exists: Yes\n";
    echo "Is writable: " . (is_writable($logFile) ? "Yes" : "No") . "\n";
    echo "File permissions: " . substr(sprintf('%o', fileperms($logFile)), -4) . "\n";
    echo "</pre>";
}

echo "<h2>Test Error Logging</h2>";
echo "<p>Check the error log file for the test message.</p>";
?> 