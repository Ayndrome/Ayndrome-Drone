-- Add OTP columns to users table
ALTER TABLE users
ADD COLUMN otp VARCHAR(6) DEFAULT NULL,
ADD COLUMN otp_expiry DATETIME DEFAULT NULL; 