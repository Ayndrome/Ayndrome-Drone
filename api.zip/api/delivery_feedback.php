<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

session_start();
$user_id = $_SESSION['user_id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $tracking_id = $data['tracking_id'] ?? '';
    $rating = $data['rating'] ?? 0;
    $feedback = $data['feedback'] ?? '';

    if (!$user_id || !$tracking_id || !$rating) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing required fields.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO delivery_feedback (user_id, tracking_id, rating, feedback) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE rating=VALUES(rating), feedback=VALUES(feedback), created_at=NOW()");
        $stmt->execute([$user_id, $tracking_id, $rating, $feedback]);
        echo json_encode(['success' => true, 'message' => 'Feedback submitted successfully.']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $tracking_id = $_GET['tracking_id'] ?? null;
    $query = "SELECT f.*, u.first_name, u.last_name FROM delivery_feedback f JOIN users u ON f.user_id = u.id";
    $params = [];
    if ($tracking_id) {
        $query .= " WHERE f.tracking_id = ?";
        $params[] = $tracking_id;
    }
    $query .= " ORDER BY f.created_at DESC";
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'feedbacks' => $feedbacks]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Method not allowed']);
