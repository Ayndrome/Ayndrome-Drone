<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

// Only allow GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Fetch the latest 50 notifications
$stmt = $pdo->prepare('SELECT id, user_id, title, description, type, status, created_at FROM users_activity WHERE type IN ("info", "warning", "blocked", "delayed", "cancelled", "custom") ORDER BY created_at DESC LIMIT 50');
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group by notification batch (title, description, type, status, created_at)
$grouped = [];
foreach ($rows as $row) {
    $key = md5($row['title'].$row['description'].$row['type'].$row['status'].$row['created_at']);
    if (!isset($grouped[$key])) {
        $grouped[$key] = [
            'title' => $row['title'],
            'description' => $row['description'],
            'type' => $row['type'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'recipients' => []
        ];
    }
    $grouped[$key]['recipients'][] = $row['user_id'];
}

// Format recipients as count or comma-separated string
$notifications = array_values(array_map(function($n) {
    $n['recipients'] = count($n['recipients']) > 5 ? (count($n['recipients']) . ' users') : implode(',', $n['recipients']);
    return $n;
}, $grouped));

// Return grouped notifications
echo json_encode(['success' => true, 'notifications' => $notifications]);
