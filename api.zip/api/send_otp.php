<?php
ob_start();

require_once 'cors.php';
require_once 'db_connect.php';
require_once 'utils.php';

date_default_timezone_set('Asia/Kolkata');
ini_set('error_log', __DIR__ . '/php_errors.log');

$vendorPath = __DIR__ . '/../vendor/autoload.php';
if (!file_exists($vendorPath)) {
    error_log("PHPMailer autoload file not found at: " . $vendorPath);
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server configuration error']);
    exit;
}
require $vendorPath;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
header('Content-Type: application/json');

// Define send_otp function for reuse
if (!function_exists('send_otp')) {
    function send_otp($email) {
        global $pdo;
        try {
            if (!$pdo) {
                error_log("Database connection failed in send_otp.php");
                return [
                    'success' => false,
                    'error' => 'Database connection error',
                    'status_code' => 500
                ];
            }
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$user) {
                error_log("User not found for email: " . $email);
                return [
                    'success' => false,
                    'error' => 'User not found',
                    'status_code' => 404
                ];
            }
            $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $otpExpiry = date('Y-m-d H:i:s', strtotime('+30 minutes'));
            $stmt = $pdo->prepare("UPDATE users SET otp = :otp, otp_expiry = :otp_expiry WHERE email = :email");
            if (!$stmt->execute([
                ':otp' => $otp,
                ':otp_expiry' => $otpExpiry,
                ':email' => $email
            ])) {
                error_log("Failed to store OTP for email: " . $email);
                return [
                    'success' => false,
                    'error' => 'Failed to store OTP',
                    'status_code' => 500
                ];
            }
            $to = $email;
            $subject = "Your OTP for Login";
            $message = '
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Your OTP for Login</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f9fafb; padding: 20px;">
      <table style="max-width: 600px; margin: auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); overflow: hidden;">
        <tr>
          <td style="padding: 20px; text-align: center;background: rgb(0,51,102);
background: linear-gradient(159deg, rgba(0,51,102,1) 0%, rgba(15,82,186,1) 100%);">
            <h2 style="margin: 0; color: white;">Ayndrome</h2>
          </td>
        </tr>
        <tr>
          <td style="padding: 30px; text-align: center;">
            <h3 style="color: #111827;">Your One-Time Password</h3>
            <p style="font-size: 16px; color: #4b5563;">Please use the following OTP to log into your account:</p>
            <div style="margin: 20px 0;">
              <span style="display: inline-block; padding: 15px 30px; font-size: 24px; background-color: #e0f2fe; color: #1d4ed8; border-radius: 8px; font-weight: bold; letter-spacing: 2px;">' . $otp . '</span>
            </div>
            <p style="color: #6b7280;">This OTP is valid for <strong>30 minutes</strong>.</p>
          </td>
        </tr>
        <tr>
          <td style="padding: 20px; text-align: center; font-size: 12px; color: #9ca3af;">
            If you did not request this, please ignore this email.<br>
            &copy; ' . date('Y') . ' Ayndrome. All rights reserved.
          </td>
        </tr>
      </table>
    </body>
    </html>';
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'shashanksaket9@gmail.com';
        $mail->Password = 'goou gtms okin wdwx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
    
        $mail->setFrom('shashanksaket9@gmail.com', 'Ayndrome Delivery');
        $mail->addAddress($email);
    
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->AltBody = 'Your OTP for Login: ' . $otp;
    
        $mail->send();
    } catch (Exception $e) {
        error_log("Failed to send OTP email to: " . $email . ' | Error: ' . $mail->ErrorInfo);
        return [
            'success' => false,
            'error' => 'Failed to send OTP email',
            'status_code' => 500
        ];
    }
    return [
        'success' => true,
        'message' => 'OTP sent successfully',
        // 'otp' => $otp // Remove in production
    ];
        } catch (Exception $e) {
            error_log("Error in send_otp.php: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'An error occurred',
                'status_code' => 500
            ];
        }
    }
}

// If called directly as endpoint, behave as before
if (basename(__FILE__) == basename($_SERVER['SCRIPT_FILENAME'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
    }
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    if (!isset($data['email'])) {
        send_json_response(['success' => false, 'error' => 'Email is required'], 400);
    }
    $email = $data['email'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        send_json_response(['success' => false, 'error' => 'Invalid email format'], 400);
    }
    $otpResponse = send_otp($email);
    if (!$otpResponse['success']) {
        send_json_response(['success' => false, 'error' => $otpResponse['error']], $otpResponse['status_code'] ?? 500);
    }
    send_json_response([
        'success' => true,
        'message' => 'OTP sent successfully',
        'email' => $email
    ]);
}

ob_end_flush();
?>