<?php
// Start output buffering
ob_start();

require_once 'cors.php';
require_once 'db_connect.php';
require_once 'utils.php';

date_default_timezone_set('Asia/Kolkata');
ini_set('error_log', __DIR__ . '/php_errors.log');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!isset($data['email'], $data['otp'], $data['new_password'])) {
    send_json_response(['success' => false, 'error' => 'Missing parameters'], 400);
}

$email = $data['email'];
$otp = $data['otp'];
$new_password = $data['new_password'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    send_json_response(['success' => false, 'error' => 'Invalid email format'], 400);
}
if (strlen($new_password) < 6) {
    send_json_response(['success' => false, 'error' => 'Password must be at least 6 characters'], 400);
}

try {
    $stmt = $pdo->prepare("SELECT otp, otp_expiry FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        send_json_response(['success' => false, 'error' => 'User not found'], 404);
    }
    if (!$user['otp'] || !$user['otp_expiry'] || $user['otp'] !== $otp) {
        send_json_response(['success' => false, 'error' => 'Invalid OTP'], 400);
    }
    if (strtotime($user['otp_expiry']) < time()) {
        send_json_response(['success' => false, 'error' => 'OTP expired'], 400);
    }
    // Hash new password
    $hashed = password_hash($new_password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("UPDATE users SET password = :password, otp = NULL, otp_expiry = NULL WHERE email = :email");
    $stmt->execute([
        ':password' => $hashed,
        ':email' => $email
    ]);
    send_json_response(['success' => true, 'message' => 'Password reset successful']);
} catch (Exception $e) {
    error_log("Error in reset_password.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'An error occurred'], 500);
}
ob_end_flush();
?>
