<?php
require_once 'db_connect.php';
require_once 'firebase_helper.php';
header('Content-Type: application/json');

if (!isset($_POST['order_id']) || !isset($_POST['order_status'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing parameters']);
    exit;
}

$order_id = $_POST['order_id'];
$order_status = $_POST['order_status'];

// Update Firebase first
$firebaseOrderPath = "drones_tracking/$order_id";
$order = firebase_get_all($firebaseOrderPath);
if ($order) {
    $order['status'] = $order_status;
    firebase_update($firebaseOrderPath, $order);
}

// Now update MySQL
$stmt = $pdo->prepare("UPDATE users_orders SET order_status = ? WHERE order_id = ?");
$success = $stmt->execute([$order_status, $order_id]);
$affected = $stmt->rowCount();

if ($success && $affected > 0) {
    echo json_encode(['success' => true]);
} else if ($success && $affected == 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Order not found or status already set']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update']);
}
