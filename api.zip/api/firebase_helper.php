<?php
// Helper for Firebase Realtime Database using Firebase Admin SDK (kreait/firebase-php)
// Requires: composer require kreait/firebase-php
// Usage: firebase_update('drones_tracking/{order_id}', $data_array);

require __DIR__.'/../vendor/autoload.php';

use Kreait\Firebase\Factory;


function firebase_update($path, $data) {
    // Path to your downloaded service account JSON
    $serviceAccountPath = __DIR__.'/ayndrome0777-firebase-adminsdk-fbsvc-c9de7787ad.json';
    $factory = (new Factory)->withServiceAccount($serviceAccountPath)
        ->withDatabaseUri('https://ayndrome0777-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();
    $database->getReference($path)->set($data);
    return true;
}

// Fetch all data from a Firebase path
function firebase_get_all($path) {
    $serviceAccountPath = __DIR__.'/ayndrome0777-firebase-adminsdk-fbsvc-c9de7787ad.json';
    $factory = (new Factory)->withServiceAccount($serviceAccountPath)
        ->withDatabaseUri('https://ayndrome0777-default-rtdb.firebaseio.com');
    $database = $factory->createDatabase();
    $snapshot = $database->getReference($path)->getSnapshot();
    return $snapshot->getValue();
}
