<?php
ob_start();
require_once 'cors.php';
require_once 'db_connect.php';

header('Content-Type: application/json');

function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['error' => 'Method not allowed'], 405);
}

try {
    if (!$pdo) {
        error_log("Database connection error");
        send_json_response(['error' => 'Database connection error'], 500);
    }

    // Get user ID from session
    session_start();
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['error' => 'User not authenticated'], 401);
    }

    $user_id = $_SESSION['user_id'];

    // Fetch activities
    $stmt = $pdo->prepare("
        SELECT 
            a.id,
            a.type,
            a.description,
            a.status,
            a.created_at,
            a.updated_at,
            u.first_name,
            u.last_name
        FROM activities a
        LEFT JOIN users u ON a.user_id = u.id
        WHERE a.user_id = :user_id
        ORDER BY a.created_at DESC
        LIMIT 10
    ");

    $stmt->execute([':user_id' => $user_id]);
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);

    send_json_response([
        'success' => true,
        'activities' => $activities
    ]);

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    send_json_response(['error' => 'Database error occurred'], 500);
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    send_json_response(['error' => 'An error occurred'], 500);
} 