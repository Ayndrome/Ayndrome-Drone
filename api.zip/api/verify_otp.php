<?php
// Start output buffering to prevent any output before headers
ob_start();

// Set session cookie parameters before starting session
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.cookie_lifetime', 86400); // 24 hours
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_domain', '');
ini_set('session.cookie_path', '/');

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Include utility functions
require_once 'utils.php';

// Set timezone to Asia/Kolkata (UTC+5:30)
date_default_timezone_set('Asia/Kolkata');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Function to send JSON response
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email']) || !isset($data['otp'])) {
    send_json_response(['success' => false, 'error' => 'Email and OTP are required'], 400);
}

$email = $data['email'];
$otp = $data['otp'];

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    send_json_response(['success' => false, 'error' => 'Invalid email format'], 400);
}

try {
    // Check if database connection is valid
    if (!$pdo) {
        error_log("Database connection failed in verify_otp.php");
        send_json_response(['success' => false, 'error' => 'Database connection error'], 500);
    }
    
    // Get user with matching email and OTP
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email AND otp = :otp AND otp_expiry > NOW()");
    $stmt->execute([
        ':email' => $email,
        ':otp' => $otp
    ]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        error_log("Invalid or expired OTP for email: " . $email);
        send_json_response(['success' => false, 'error' => 'Invalid or expired OTP'], 401);
    }

    // Clear OTP after successful verification
    $stmt = $pdo->prepare("UPDATE users SET otp = NULL, otp_expiry = NULL WHERE email = :email");
    $stmt->execute([':email' => $email]);

    // Remove sensitive data before sending response
    unset($user['password']);
    unset($user['otp']);
    unset($user['otp_expiry']);

    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['first_name'] = $user['first_name'];
    $_SESSION['last_name'] = $user['last_name'];
    
    // Return success response with user data
    send_json_response([
        'success' => true,
        'message' => 'OTP verified successfully',
        'user' => $user
    ]);

} catch (Exception $e) {
    error_log("Error in verify_otp.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'Server error'], 500);
}

// End output buffering and flush
ob_end_flush();
?> 