<?php
// Start output buffering
ob_start();

// Include required files
require_once 'cors.php';
require_once 'db_connect.php';
require_once 'utils.php';

// Set content type to JSON
header('Content-Type: application/json');


try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['success' => false, 'error' => 'Not logged in'], 401);
    }

    // Check if it's a POST request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
    }

    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        send_json_response(['success' => false, 'error' => 'Invalid input data'], 400);
    }

    // Validate input data
    $allowedFields = ['first_name', 'last_name', 'email', 'phone', 'address'];
    $updateData = array_intersect_key($data, array_flip($allowedFields));

    if (empty($updateData)) {
        send_json_response(['success' => false, 'error' => 'No valid fields to update'], 400);
    }

    // Check if email is being updated and if it's already taken
    if (isset($updateData['email'])) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$updateData['email'], $_SESSION['user_id']]);
        if ($stmt->rowCount() > 0) {
            send_json_response(['success' => false, 'error' => 'Email already taken'], 400);
        }
    }

    // Build update query
    $setClause = implode(' = ?, ', array_keys($updateData)) . ' = ?';
    $values = array_values($updateData);
    $values[] = $_SESSION['user_id'];

    $query = "UPDATE users SET $setClause WHERE id = ?";
    $stmt = $pdo->prepare($query);
    
    if (!$stmt->execute($values)) {
        throw new Exception('Failed to update profile');
    }

    // Get updated user data
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, email, phone, address FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Update session data
    $_SESSION['first_name'] = $user['first_name'];
    $_SESSION['last_name'] = $user['last_name'];
    $_SESSION['email'] = $user['email'];

    send_json_response([
        'success' => true,
        'message' => 'Profile updated successfully',
        'user' => $user
    ]);

} catch (Exception $e) {
    error_log("Error in update_profile.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'An error occurred'], 500);
}

// End output buffering and flush
ob_end_flush();
?> 