<?php
// send_twilio_call.php (Studio Flow version, no SDK required)
// Usage: sendTwilioCall($toPhone)
// Calls a Twilio Studio Flow using REST API (no composer dependency)

function sendTwilioCall($toPhone) {
    // Set your credentials and Flow info
    $twilioSid = getenv('TWILIO_SID') ?: 'ACf28e8b1faac4c1fd8ce6614137bee033';
    $twilioAuthToken = getenv('TWILIO_AUTH_TOKEN') ?: 'a376903e504b495989b3dd30cacdcdba';
    $twilioNumber = getenv('TWILIO_NUMBER') ?: '+18055726865'; // Your Twilio phone number
    $flowSid = getenv('TWILIO_FLOW_SID') ?: 'FW7326c43a5a09497b6a6b5c165bd85610'; // Your Studio Flow SID

    $url = "https://studio.twilio.com/v2/Flows/$flowSid/Executions";
    $data = [
        'To' => $toPhone,
        'From' => $twilioNumber
    ];
    $postFields = http_build_query($data);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_USERPWD, "$twilioSid:$twilioAuthToken");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // 201 Created means success
    return $httpCode === 201;
}

// Example usage (uncomment to test):
// sendTwilioCall('+918957111589');
