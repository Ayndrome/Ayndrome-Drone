<?php
require_once 'db_connect.php';
require_once 'cors.php';


header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare("SELECT id, card_holder_name, last4, expiry_month, expiry_year, card_type, created_at FROM saved_payment WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->execute([':user_id' => $user_id]);
    $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'cards' => $cards]);
} catch (Exception $e) {
    error_log('Error fetching saved cards: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Could not fetch saved cards']);
}
