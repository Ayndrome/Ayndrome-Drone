<?php
require_once 'db_connect.php';
require_once 'firebase_helper.php';
header('Content-Type: application/json');
session_start();

file_put_contents(__DIR__.'/cancel_debug.log', json_encode([
    'time' => date('c'),
    'session' => $_SESSION,
    'post' => $_POST
]).PHP_EOL, FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;
$order_id = $_POST['order_id'] ?? null;

if (!$user_id || !$order_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing parameters']);
    exit;
}

// Fetch order info from Firebase (drones_tracking)
$firebaseOrderPath = "drones_tracking/$order_id";
$order = firebase_get_all($firebaseOrderPath);

if (!$order) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Order not found in Firebase']);
    exit;
}

// Allow cancellation only if status is "Arriving at pickup in X min" (dynamic string)
// or legacy statuses: 'pending', 'processing', 'preparing', 'in_transit'
$lowerStatus = strtolower($order['status']);
$canCancel = false;
if (strpos($order['status'], 'Arriving at pickup in') === 0) {
    $canCancel = true;
} elseif (in_array($lowerStatus, ['pending', 'processing', 'preparing'])) {
    $canCancel = true;
}
if (!$canCancel) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Order cannot be cancelled after pickup']);
    exit;
}

$created_at = strtotime($order['created_at']);
$now = time();
$timeout = 120; // 2 minutes in seconds

if (($now - $created_at) > $timeout) {
    // Optionally, you can set a fine here
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Cancellation period expired. Cancellation not allowed or fine will be imposed.']);
    exit;
}

// Cancel the order in Firebase (for Tracking.jsx UI)
try {
    $firebasePath = "drones_tracking/$order_id";
    // Get existing data
    $tracking = firebase_get_all($firebasePath);
    if ($tracking) {
        $tracking['status'] = 'cancelled';
        $tracking['progress'] = 0;
        $tracking['eta'] = 'Cancelled';
        firebase_update($firebasePath, $tracking);
    }

    // Also update the order status in MySQL
    $stmt = $pdo->prepare("UPDATE users_orders SET order_status = ? WHERE order_id = ?");
    $stmt->execute(['cancelled', $order_id]);

    // Insert a cancellation notification for the user
    $notifStmt = $pdo->prepare("INSERT INTO users_activity (user_id, order_id, title, description, status, type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $notifStmt->execute([
        $user_id,
        $order_id, // Use order_id as stored in Firebase
        'Order Cancelled',
        'Your order has been cancelled as per your request.',
        'cancelled',
        'notification',
        date('Y-m-d H:i:s')
    ]);
    if ($notifStmt->errorCode() !== '00000') {
        error_log('Insert user_activity failed: ' . implode(' ', $notifStmt->errorInfo()));
        echo json_encode(['success' => false, 'error' => 'Failed to insert cancellation notification: ' . implode(' ', $notifStmt->errorInfo())]);
        exit;
    }
} catch (Exception $e) {
    error_log('Failed to update Firebase, MySQL, or insert notification on cancel: ' . $e->getMessage());
}

// Insert a notification message for the user (for Profile.jsx > Messages section)
try {
    // Removed the duplicate notification insertion
} catch (Exception $e) {
    // Log error but do not block cancellation response
    error_log('Failed to insert notification: ' . $e->getMessage());
}
echo json_encode(['success' => true, 'message' => 'Order cancelled successfully.']);
