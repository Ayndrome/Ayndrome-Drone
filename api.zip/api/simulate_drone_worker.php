<?php
ini_set('max_execution_time', 0);
set_time_limit(0);

require_once 'db_connect.php';
require_once 'send_email.php';
require_once 'firebase_helper.php';

// Get order_id from CLI argument
if ($argc < 2) {
    exit("order_id required\n");
}
$order_id = $argv[1];

// ======== DELIVERY SIMULATION MODE PARAMS ========
// Accept mode, steps, and sleep from CLI args (from simulate_drone_delivery.php)
if ($argc < 6) {
    error_log("simulate_drone_worker.php: Not enough arguments! Got $argc");
    exit("Usage: php simulate_drone_worker.php <order_id> <delivery_mode> <stepsToPickup> <stepsToDestination> <stepSleep>\n");
}
$delivery_mode = $argv[2];
$stepsToPickup = intval($argv[3]);
$stepsToDestination = intval($argv[4]);
$stepSleep = intval($argv[5]);
$allSteps = $stepsToPickup + $stepsToDestination;
// ======== END SIM MODE PARAMS ========

// 1. Fetch order and tracking info
$stmt = $pdo->prepare("SELECT * FROM users_orders WHERE order_id = :order_id");
$stmt->execute([':order_id' => $order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$order) exit("Order not found\n");

$stmt2 = $pdo->prepare("SELECT * FROM track_parcels WHERE order_id = :order_id");
$stmt2->execute([':order_id' => $order_id]);
$parcel = $stmt2->fetch(PDO::FETCH_ASSOC);
if (!$parcel) exit("Parcel not found\n");

error_log("ORDER COORDS: pickup_lat=" . $order['pickup_lat'] . ", pickup_lng=" . $order['pickup_lng'] . ", delivery_lat=" . $order['delivery_lat'] . ", delivery_lng=" . $order['delivery_lng']);
// Get coordinates from users_orders table (which is already fetched as $order)
function validCoord($lat, $lng) {
    return isset($lat, $lng) && is_numeric($lat) && is_numeric($lng)
        && $lat >= -90 && $lat <= 90 && $lng >= -180 && $lng <= 180;
}
if (validCoord($order['pickup_lat'], $order['pickup_lng'])) {
    $from = $order['pickup_lat'] . ',' . $order['pickup_lng'];
} else {
    $from = '28.6139,77.2090';
}
if (validCoord($order['delivery_lat'], $order['delivery_lng'])) {
    $to = $order['delivery_lat'] . ',' . $order['delivery_lng'];
} else {
    $to = '28.7041,77.1025';
}
// Optionally log for debug
error_log("FROM: $from, TO: $to");

// Helper to interpolate between two points
function interpolateCoords($from, $to, $steps) {
    list($fromLat, $fromLng) = explode(',', $from);
    list($toLat, $toLng) = explode(',', $to);
    $coords = [];
    for ($i = 0; $i <= $steps; $i++) {
        $lat = $fromLat + ($toLat - $fromLat) * $i / $steps;
        $lng = $fromLng + ($toLng - $fromLng) * $i / $steps;
        $coords[] = "$lat,$lng";
    }
    return $coords;
}

// Route calculation
$routeToPickup = interpolateCoords($from, $from, $stepsToPickup); // Simulate drone approaching pickup
$routeToDest = interpolateCoords($from, $to, $stepsToDestination); // Simulate drone flying to destination
$route = array_merge($routeToPickup, $routeToDest);

// Fetch the original created_at from Firebase
$firebasePath = "drones_tracking/$order_id";
$originalTracking = firebase_get_all($firebasePath);
$createdAt = isset($originalTracking['created_at']) ? $originalTracking['created_at'] : date('c');

// Initial status
$status = 'preparing';
$progress = 0;

for ($i = 0; $i < count($route); $i++) {
    // Check for cancellation in Firebase before proceeding
    $latestTracking = firebase_get_all("drones_tracking/$order_id");
    if (isset($latestTracking['status']) && $latestTracking['status'] === 'cancelled') {
        error_log("Order $order_id cancelled. Stopping simulation.");
        break;
    }
    $currentLoc = $route[$i];

    // --- STATUS LOGIC ---
    if ($i < $stepsToPickup) {
        // Approaching pickup
        $status = ($i < $stepsToPickup-1)
            ? 'Arriving at pickup in ' . (($stepsToPickup-$i)*$stepSleep/60) . ' min'
            : 'Parcel Picked Up';
    } else if ($i < $allSteps-1) {
        $status = 'in_transit';
    } else {
        $status = 'delivered';
    }
    // On last step, force exact delivery location
    if (
        $i === count($route) - 1 ||
        $status === 'delivered' ||
        $progress === 100 ||
        $etaStr === 'Delivered'
    ) {
        $currentLoc = $to;
    }
    $eta = ($allSteps - $i) * $stepSleep / 60;
    $etaStr = ($i === $allSteps-1) ? 'Delivered' : round($eta,1).' min';

    $update = [
        'current_location' => $currentLoc,
        'status' => $status,
        'progress' => ($i === $allSteps-1) ? 100 : intval(($i / $allSteps) * 100),
        'eta' => $etaStr,
        'from_location' => $from,
        'to_location' => $to,
        'pickup_coords' => $from,
        'delivery_coords' => $to,
        'order_id' => $order_id,
        'tracking_id' => isset($parcel['tracking_id']) ? $parcel['tracking_id'] : '',
        'user_id' => isset($parcel['user_id']) ? $parcel['user_id'] : '',
        'drone_id' => isset($parcel['drone_id']) ? $parcel['drone_id'] : '',
        'created_at' => $createdAt,
    ];

    firebase_update("drones_tracking/$order_id", $update);
    $sqlStatus = $update['status'];
    $progress = $update['progress'];
    $pdo->prepare("UPDATE track_parcels SET status=:status, progress=:progress, current_location=:loc, last_updated=NOW() WHERE order_id=:order_id")
        ->execute([
            ':status' => $sqlStatus,
            ':progress' => $progress,
            ':loc' => $currentLoc,
            ':order_id' => $order_id
        ]);
    $pdo->prepare("UPDATE users_orders SET order_status=:status WHERE order_id=:order_id")
        ->execute([
            ':status' => $sqlStatus,
            ':order_id' => $order_id
        ]);
    sleep($stepSleep);
}

// Final update: delivered
// Double-check for cancellation before marking as delivered
$latestTracking = firebase_get_all("drones_tracking/$order_id");
if (!isset($latestTracking['status']) || $latestTracking['status'] !== 'cancelled') {
    $update = [
        'current_location' => $route[$allSteps-1],
        'status' => 'delivered',
        'progress' => 100,
        'eta' => 'Delivered',
        'from_location' => $from,
        'to_location' => $to,
        'pickup_coords' => $from,
        'delivery_coords' => $to,
        'order_id' => $order_id,
        'tracking_id' => isset($parcel['tracking_id']) ? $parcel['tracking_id'] : '',
        'user_id' => isset($parcel['user_id']) ? $parcel['user_id'] : '',
        'drone_id' => isset($parcel['drone_id']) ? $parcel['drone_id'] : '',
        'created_at' => $createdAt,
    ];
    firebase_update("drones_tracking/$order_id", $update);
    $pdo->prepare("UPDATE track_parcels SET status=:status, progress=:progress, current_location=:loc, last_updated=NOW() WHERE order_id=:order_id")
        ->execute([
            ':status' => 'delivered',
            ':progress' => 100,
            ':loc' => $route[$allSteps-1],
            ':order_id' => $order_id
        ]);
    // Final sync for users_orders table
    $pdo->prepare("UPDATE users_orders SET order_status=:status WHERE order_id=:order_id")
        ->execute([
            ':status' => 'delivered',
            ':order_id' => $order_id
        ]);
    // Send delivery confirmation email
    $userEmail = $order['user_email'] ?? 'demo@example.com';
    $userName = $order['user_name'] ?? 'Customer';
    $orderDetails = [
        'order_id' => $order['order_id'],
        'pickup_address' => $order['pickup_address'],
        'delivery_address' => $order['delivery_address'],
        'scheduled_date' => $order['scheduled_date'],
        'scheduled_time' => $order['scheduled_time'],
        'package_dimensions' => $order['package_dimensions'],
        'total_amount' => $order['total_amount'],
        'status' => 'Delivered',
    ];
    sendOrderConfirmationEmail($userEmail, $userName, $orderDetails);
} else {
    error_log("Order $order_id was cancelled before delivery. Not marking as delivered.");
}
