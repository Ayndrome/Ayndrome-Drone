<?php
// Start output buffering
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include Firebase configuration
require_once 'firebase_helper.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable display_errors to prevent HTML output
ini_set('log_errors', 1); // Enable error logging
ini_set('error_log', 'php_errors.log'); // Set error log file

// Set content type to JSON
header('Content-Type: application/json');

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $trackingId = isset($_GET['tracking_id']) ? $_GET['tracking_id'] : null;

    // Fetch all drones_tracking for this user
    $firebasePath = 'drones_tracking';
    $trackingData = firebase_get_all($firebasePath);

    // Filter by user_id and tracking_id if provided
    $parcels = array_filter($trackingData ?? [], function($row) use ($user_id, $trackingId) {
        if (!isset($row['user_id']) || $row['user_id'] != $user_id) return false;
        if ($trackingId && (!isset($row['tracking_id']) || $row['tracking_id'] != $trackingId)) return false;
        return true;
    });

    $parcels = array_map(function($row) {
        return [
            'id' => $row['tracking_id'],
            'order_id' => $row['order_id'],
            'status' => $row['status'],
            'progress' => (int)$row['progress'],
            'eta' => $row['eta'],
            'current_location' => $row['current_location'],
            'from_location' => $row['from_location'],
            'to_location' => $row['to_location'],
            'drone_id' => $row['drone_id'],
            'scheduled_date' => $row['scheduled_date'] ?? '',
            'scheduled_time' => $row['scheduled_time'] ?? '',
        ];
    }, $parcels);

    echo json_encode([
        'success' => true,
        'parcels' => array_values($parcels)
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

ob_end_flush();
?>