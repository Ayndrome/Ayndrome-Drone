<?php
// Start output buffering
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Set content type to JSON
header('Content-Type: application/json');

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Not logged in'
    ]);
    exit();
}

try {
    // Begin transaction
    $pdo->beginTransaction();

    // Get orders that need to be synced
    $query = "
        SELECT 
            uo.order_id,
            uo.user_id,
            uo.order_status,
            uo.pickup_address,
            uo.delivery_address,
            uo.package_dimensions,
            uo.total_amount,
            uo.scheduled_date,
            uo.scheduled_time
        FROM users_orders uo
        WHERE uo.user_id = :user_id
        AND uo.order_status = 'pending'
    ";

    $stmt = $pdo->prepare($query);
    if (!$stmt) {
        throw new Exception('Failed to prepare query: ' . implode(' ', $pdo->errorInfo()));
    }

    $stmt->execute([':user_id' => $_SESSION['user_id']]);
    if ($stmt->errorCode() !== '00000') {
        throw new Exception('Failed to execute query: ' . implode(' ', $stmt->errorInfo()));
    }

    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Insert or update track_parcels
    foreach ($orders as $order) {
        // Check if tracking_id already exists
        $checkStmt = $pdo->prepare("SELECT id FROM track_parcels WHERE tracking_id = :tracking_id");
        if (!$checkStmt) {
            throw new Exception('Failed to prepare check query: ' . implode(' ', $pdo->errorInfo()));
        }

        $checkStmt->execute([':tracking_id' => $order['order_id']]);
        if ($checkStmt->errorCode() !== '00000') {
            throw new Exception('Failed to execute check query: ' . implode(' ', $checkStmt->errorInfo()));
        }

        $exists = $checkStmt->fetch();

        if ($exists) {
            // Update existing record
            $updateStmt = $pdo->prepare("
                UPDATE track_parcels 
                SET status = :status,
                    last_updated = CURRENT_TIMESTAMP
                WHERE tracking_id = :tracking_id
            ");
            if (!$updateStmt) {
                throw new Exception('Failed to prepare update query: ' . implode(' ', $pdo->errorInfo()));
            }

            $updateStmt->execute([
                ':status' => $order['order_status'],
                ':tracking_id' => $order['order_id']
            ]);
            if ($updateStmt->errorCode() !== '00000') {
                throw new Exception('Failed to execute update query: ' . implode(' ', $updateStmt->errorInfo()));
            }
        } else {
            // Insert new record
            $insertStmt = $pdo->prepare("
                INSERT INTO track_parcels (
                    order_id,
                    tracking_id,
                    user_id,
                    status,
                    progress,
                    eta,
                    current_location,
                    last_updated,
                    from_location,
                    to_location,
                    items,
                    cost,
                    scheduled_date,
                    scheduled_time
                ) VALUES (
                    :order_id,
                    :tracking_id,
                    :user_id,
                    :status,
                    0,
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP,
                    :from_location,
                    :to_location,
                    :items,
                    :cost,
                    :scheduled_date,
                    :scheduled_time
                )
            ");
            if (!$insertStmt) {
                throw new Exception('Failed to prepare insert query: ' . implode(' ', $pdo->errorInfo()));
            }

            $insertStmt->execute([
                ':order_id' => $order['order_id'], // string order_id
                ':tracking_id' => $order['order_id'], // string tracking_id (can be same as order_id)
                ':user_id' => $order['user_id'],
                ':status' => $order['order_status'],
                ':from_location' => $order['pickup_address'],
                ':to_location' => $order['delivery_address'],
                ':items' => $order['package_dimensions'],
                ':cost' => $order['total_amount'],
                ':scheduled_date' => $order['scheduled_date'],
                ':scheduled_time' => $order['scheduled_time']
            ]);
            if ($insertStmt->errorCode() !== '00000') {
                throw new Exception('Failed to execute insert query: ' . implode(' ', $insertStmt->errorInfo()));
            }
        }
    }

    // Commit transaction
    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Track parcels synced successfully'
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Error in sync_track_parcels.php: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to sync track parcels: ' . $e->getMessage()
    ]);
}

// End output buffering and flush
ob_end_flush();
?>