<?php
// Start output buffering to prevent any output before headers
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Include utility functions
require_once 'utils.php';

// Set timezone
date_default_timezone_set('Asia/Kolkata');

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Function to send JSON response
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if it's a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

try {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if user is logged in
    if (isset($_SESSION['user_id'])) {
        // Get user data
        $stmt = $pdo->prepare("SELECT id, email, first_name, last_name, phone, created_at FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Get user activity
            $stmt = $pdo->prepare("SELECT * FROM users_activity WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
            $stmt->execute([$_SESSION['user_id']]);
            $activity = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Get delivery history
            $stmt = $pdo->prepare("SELECT * FROM delivery_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
            $stmt->execute([$_SESSION['user_id']]);
            $deliveryHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Get tracked parcels
            $stmt = $pdo->prepare("SELECT * FROM track_parcel WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
            $stmt->execute([$_SESSION['user_id']]);
            $trackedParcels = $stmt->fetchAll(PDO::FETCH_ASSOC);

            send_json_response([
                'success' => true,
                'loggedIn' => true,
                'user' => $user,
                'activity' => $activity,
                'deliveryHistory' => $deliveryHistory,
                'trackedParcels' => $trackedParcels
            ]);
        }
    }

    // If we get here, user is not logged in
    send_json_response([
        'success' => true,
        'loggedIn' => false,
        'message' => 'Not logged in'
    ]);

} catch (Exception $e) {
    error_log("Error in check_session.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'An error occurred'], 500);
}

// End output buffering and flush
ob_end_flush();
?> 