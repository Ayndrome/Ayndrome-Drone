<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

// Get traffic grouped by day (last 30 days)
try {
    $stmt = $pdo->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM users_orders GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 30");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Reverse for chronological order
    $rows = array_reverse($rows);
    echo json_encode(['success' => true, 'traffic' => $rows]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
