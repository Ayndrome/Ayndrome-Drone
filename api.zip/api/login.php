<?php
// Start output buffering to prevent any output before headers
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Include utility functions
require_once 'utils.php';

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

// Get JSON data from request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate input
if (!isset($data['email']) || !isset($data['password'])) {
    send_json_response(['success' => false, 'error' => 'Email and password are required'], 400);
}

$email = $data['email'];
$password = $data['password'];

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    send_json_response(['success' => false, 'error' => 'Invalid email format'], 400);
}

try {
    // Check if database connection is valid
    if (!$pdo) {
        error_log("Database connection failed in login.php");
        send_json_response(['success' => false, 'error' => 'Database connection error'], 500);
    }
    
    // Check if user exists and credentials are valid
    $stmt = $pdo->prepare("SELECT id, email, password FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        error_log("User not found for email: " . $email);
        send_json_response(['success' => false, 'error' => 'Invalid credentials'], 401);
    }
    
    if (!password_verify($password, $user['password'])) {
        error_log("Invalid password for email: " . $email);
        send_json_response(['success' => false, 'error' => 'Invalid credentials'], 401);
    }
    
    // If credentials are valid, send OTP
    require_once 'send_otp.php';
    $otpResponse = send_otp($email);
    
    if (isset($otpResponse['error'])) {
        send_json_response(['success' => false, 'error' => $otpResponse['error']], $otpResponse['status_code'] ?? 500);
    }
    
    send_json_response([
        'success' => true,
        'message' => 'OTP sent successfully',
        'email' => $email
    ]);
    
} catch (Exception $e) {
    error_log("Error in login.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'An error occurred'], 500);
}

// End output buffering and flush
ob_end_flush();
?> 