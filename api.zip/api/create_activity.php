<?php
// Include database connection
require_once 'db_connect.php';

function createUserActivity($pdo, $userId, $title, $description, $type, $status = 'pending', $orderId = null) {
    try {
        $query = "
            INSERT INTO users_activity (
                user_id,
                order_id,
                title,
                description,
                status,
                type
            ) VALUES (
                :user_id,
                :order_id,
                :title,
                :description,
                :status,
                :type
            )
        ";
        
        $stmt = $pdo->prepare($query);
        if (!$stmt) {
            error_log("Failed to prepare activity query: " . implode(' ', $pdo->errorInfo()));
            return false;
        }
        
        $stmt->execute([
            ':user_id' => $userId,
            ':order_id' => $orderId,
            ':title' => $title,
            ':description' => $description,
            ':status' => $status,
            ':type' => $type
        ]);
        
        if ($stmt->errorCode() !== '00000') {
            error_log("Failed to execute activity query: " . implode(' ', $stmt->errorInfo()));
            return false;
        }
        
        return true;
    } catch (Exception $e) {
        error_log("Error creating user activity: " . $e->getMessage());
        return false;
    }
}
?> 