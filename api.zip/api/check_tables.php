<?php
require_once 'db_connect.php';

try {
    // Check if track_parcels table exists
    $checkTable = $pdo->query("SHOW TABLES LIKE 'track_parcels'");
    if ($checkTable->rowCount() == 0) {
        // Create track_parcels table if it doesn't exist
        $createTable = "
            CREATE TABLE IF NOT EXISTS `track_parcels` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `ride_id` int(11) NOT NULL,
                `tracking_id` varchar(20) NOT NULL,
                `status` enum('processing','in_transit','delivered','cancelled') NOT NULL,
                `progress` int(11) NOT NULL DEFAULT 0 COMMENT 'Progress percentage',
                `eta` varchar(50) DEFAULT NULL,
                `current_location` varchar(255) DEFAULT NULL,
                `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `tracking_id` (`tracking_id`),
                KEY `ride_id` (`ride_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        
        $pdo->exec($createTable);
        echo "Created track_parcels table\n";
    }

    // Check if users_orders table exists
    $checkTable = $pdo->query("SHOW TABLES LIKE 'users_orders'");
    if ($checkTable->rowCount() == 0) {
        // Create users_orders table if it doesn't exist
        $createTable = "
            CREATE TABLE IF NOT EXISTS `users_orders` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `order_id` varchar(20) NOT NULL,
                `pickup_address` varchar(255) NOT NULL,
                `delivery_address` varchar(255) NOT NULL,
                `scheduled_date` date DEFAULT NULL,
                `scheduled_time` time DEFAULT NULL,
                `package_dimensions` varchar(255) DEFAULT NULL,
                `total_amount` decimal(10,2) DEFAULT NULL,
                `order_status` enum('pending','shipped','delivered','in_transit','processing','not_yet_delivered') NOT NULL DEFAULT 'pending',
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `user_id` (`user_id`),
                UNIQUE KEY `order_id` (`order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ";
        
        $pdo->exec($createTable);
        echo "Created users_orders table\n";
    }

    // Verify table structures
    $tables = ['track_parcels', 'users_orders'];
    foreach ($tables as $table) {
        echo "\nStructure of $table table:\n";
        $result = $pdo->query("DESCRIBE $table");
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            echo implode("\t", $row) . "\n";
        }
    }

    echo "\nAll tables verified successfully!\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Stack trace: " . $e->getTraceAsString() . "\n";
}
?> 