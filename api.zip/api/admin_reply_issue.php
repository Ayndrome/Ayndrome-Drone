<?php
require_once 'db_connect.php';
require_once 'send_email.php';
require '../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
header('Content-Type: application/json');

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$issue_id = isset($data['issue_id']) ? intval($data['issue_id']) : 0;
$message = isset($data['message']) ? trim($data['message']) : '';

if (!$issue_id || !$message) {
    echo json_encode(['success' => false, 'error' => 'Missing issue_id or message']);
    exit;
}

try {
    // Get user email by joining user_issues and users
    $stmt = $pdo->prepare('SELECT u.email, u.first_name, u.last_name FROM user_issues ui JOIN users u ON ui.user_id = u.id WHERE ui.id = ?');
    $stmt->execute([$issue_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'User not found for this issue']);
        exit;
    }
    $to = $user['email'];
    $name = $user['first_name'] . ' ' . $user['last_name'];

    // Use PHPMailer via send_email.php
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'shashanksaket9@gmail.com';
        $mail->Password = 'goou gtms okin wdwx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('shashanksaket9@gmail.com', 'Ayndrome Admin');
        $mail->addAddress($to, $name);

        $mail->isHTML(true);
        $mail->Subject = 'Response to Your Reported Issue';
        $mail->Body = "<html><body style='background:#f7f7f7;padding:0;margin:0;'>"
            . "<div style='max-width:600px;margin:40px auto;background:#fff;border-radius:6px;padding:32px 24px;font-family:sans-serif;color:#222;border:1px solid #e5e7eb;'>"
            . "<h2 style='margin-top:0;margin-bottom:18px;font-size:22px;font-weight:600;color:#1e293b;'>Ayndrome Support Response</h2>"
            . "<p style='margin-bottom:16px;'>Dear $name,</p>"
            . "<p style='margin-bottom:20px;'>Thank you for contacting Ayndrome Support. Please find our response to your reported issue below:</p>"
            . "<div style='background:#f3f4f6;border-left:4px solid #2563eb;padding:18px 16px;margin-bottom:24px;border-radius:4px;'>"
            . "<strong>Admin Reply:</strong><br>"
            . nl2br(htmlspecialchars($message)) . "</div>"
            . "<p style='margin-bottom:0;'>If you have any further questions or concerns, feel free to reply to this email or contact our support team.</p>"
            . "<p style='margin-top:22px;margin-bottom:0;'>Best regards,<br>Ayndrome Support Team</p>"
            . "</div></body></html>";
        $mail->AltBody = "Dear $name,\n\nAdmin reply: $message\n\nThank you for contacting Ayndrome Support.\n\nBest regards,\nAyndrome Support Team";

        $mail->send();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        error_log("Email sending failed: " . $mail->ErrorInfo);
        echo json_encode(['success' => false, 'error' => 'Failed to send email: ' . $mail->ErrorInfo]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
