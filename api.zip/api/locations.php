<?php
// Start output buffering
ob_start();

// Include required files
require_once 'cors.php';
require_once 'db_connect.php';
require_once 'utils.php';

// Set content type to JSON
header('Content-Type: application/json');

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['success' => false, 'error' => 'Not logged in'], 401);
    }

    $user_id = $_SESSION['user_id'];

    // Handle different HTTP methods
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            // Fetch user locations
            $stmt = $pdo->prepare("SELECT * FROM users_locations WHERE user_id = ? ORDER BY is_default DESC, created_at DESC");
            $stmt->execute([$user_id]);
            $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            send_json_response([
                'success' => true,
                'locations' => $locations
            ]);
            break;

        case 'POST':
            // Add new location
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['name']) || !isset($data['address']) || !isset($data['type'])) {
                send_json_response(['success' => false, 'error' => 'Invalid input data'], 400);
            }

            // Validate type
            $validTypes = ['home', 'work', 'other'];
            if (!in_array($data['type'], $validTypes)) {
                send_json_response(['success' => false, 'error' => 'Invalid location type'], 400);
            }

            // If this is set as default, unset other defaults
            if (isset($data['is_default']) && $data['is_default']) {
                $stmt = $pdo->prepare("UPDATE users_locations SET is_default = FALSE WHERE user_id = ?");
                $stmt->execute([$user_id]);
            }

            // Insert new location
            $stmt = $pdo->prepare("INSERT INTO users_locations (user_id, name, address, type, is_default) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $user_id,
                $data['name'],
                $data['address'],
                $data['type'],
                $data['is_default'] ?? false
            ]);

            $location_id = $pdo->lastInsertId();
            
            // Fetch the newly created location
            $stmt = $pdo->prepare("SELECT * FROM users_locations WHERE id = ?");
            $stmt->execute([$location_id]);
            $location = $stmt->fetch(PDO::FETCH_ASSOC);

            send_json_response([
                'success' => true,
                'message' => 'Location added successfully',
                'location' => $location
            ]);
            break;

        case 'PUT':
            // Update location
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id'])) {
                send_json_response(['success' => false, 'error' => 'Invalid input data'], 400);
            }

            // Check if location belongs to user
            $stmt = $pdo->prepare("SELECT * FROM users_locations WHERE id = ? AND user_id = ?");
            $stmt->execute([$data['id'], $user_id]);
            if ($stmt->rowCount() === 0) {
                send_json_response(['success' => false, 'error' => 'Location not found'], 404);
            }

            // If this is set as default, unset other defaults
            if (isset($data['is_default']) && $data['is_default']) {
                $stmt = $pdo->prepare("UPDATE users_locations SET is_default = FALSE WHERE user_id = ? AND id != ?");
                $stmt->execute([$user_id, $data['id']]);
            }

            // Build update query
            $allowedFields = ['name', 'address', 'type', 'is_default'];
            $updateData = array_intersect_key($data, array_flip($allowedFields));
            
            if (empty($updateData)) {
                send_json_response(['success' => false, 'error' => 'No valid fields to update'], 400);
            }

            $setClause = implode(' = ?, ', array_keys($updateData)) . ' = ?';
            $values = array_values($updateData);
            $values[] = $data['id'];
            $values[] = $user_id;

            $query = "UPDATE users_locations SET $setClause WHERE id = ? AND user_id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute($values);

            // Fetch updated location
            $stmt = $pdo->prepare("SELECT * FROM users_locations WHERE id = ?");
            $stmt->execute([$data['id']]);
            $location = $stmt->fetch(PDO::FETCH_ASSOC);

            send_json_response([
                'success' => true,
                'message' => 'Location updated successfully',
                'location' => $location
            ]);
            break;

        case 'DELETE':
            // Delete location
            $location_id = $_GET['id'] ?? null;
            
            if (!$location_id) {
                send_json_response(['success' => false, 'error' => 'Location ID required'], 400);
            }

            // Check if location belongs to user
            $stmt = $pdo->prepare("SELECT * FROM users_locations WHERE id = ? AND user_id = ?");
            $stmt->execute([$location_id, $user_id]);
            if ($stmt->rowCount() === 0) {
                send_json_response(['success' => false, 'error' => 'Location not found'], 404);
            }

            // Delete location
            $stmt = $pdo->prepare("DELETE FROM users_locations WHERE id = ? AND user_id = ?");
            $stmt->execute([$location_id, $user_id]);

            send_json_response([
                'success' => true,
                'message' => 'Location deleted successfully'
            ]);
            break;

        default:
            send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
    }

} catch (Exception $e) {
    error_log("Error in locations.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'An error occurred'], 500);
}

// End output buffering and flush
ob_end_flush();
?> 