<?php
ini_set('max_execution_time', 0); // Allow unlimited execution time
set_time_limit(0); // Allow unlimited execution time

// Simulate drone delivery for a given order_id (string). This script is triggered after payment is successful.
// Usage: POST with { order_id: 'DR-...' }
// This is a fake simulation, but is structured so you can later make it real-time or event-driven.

require_once 'db_connect.php';
require_once 'send_email.php';
require_once 'firebase_helper.php';
// require_once 'send_twilio_call.php'; // To be created

// --- CONFIG ---
define('SIM_DRONE_PHONE', '8957111589'); // For Twilio call
define('SIM_PICKUP_TIME', 2 * 60); // 2 minutes in seconds
define('SIM_DELIVERY_TIME', 5 * 60); // 5 minutes in seconds

// ======== DELIVERY SIMULATION MODE ========
$delivery_mode = 'real'; 

// Calculate ETA and steps
function haversineDistance($from, $to) {
    list($lat1, $lng1) = explode(',', $from);
    list($lat2, $lng2) = explode(',', $to);
    $earthRadius = 6371; // km
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng/2) * sin($dLng/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $earthRadius * $c; // in km
}

// Assume drone speed (km/h)
$drone_speed_kmh = 36; // 10 m/s

header('Content-Type: application/json');

// Helper: Fake drone path (lat/lng pairs)
function getFakeDronePath($from, $to, $steps = 10) {
    // $from/$to: "lat,lng"
    list($fromLat, $fromLng) = explode(',', $from);
    list($toLat, $toLng) = explode(',', $to);
    $path = [];
    for ($i = 0; $i <= $steps; $i++) {
        $lat = $fromLat + ($toLat - $fromLat) * $i / $steps;
        $lng = $fromLng + ($toLng - $fromLng) * $i / $steps;
        $path[] = "$lat,$lng";
    }
    return $path;
}

// --- MAIN ---
$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['order_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'order_id required']);
    exit;
}
$order_id = $data['order_id'];

// 1. Fetch order and tracking info
$stmt = $pdo->prepare("SELECT * FROM users_orders WHERE order_id = :order_id");
$stmt->execute([':order_id' => $order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$order) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Order not found']);
    exit;
}

$stmt2 = $pdo->prepare("SELECT * FROM track_parcels WHERE order_id = :order_id");
$stmt2->execute([':order_id' => $order_id]);
$parcel = $stmt2->fetch(PDO::FETCH_ASSOC);
if (!$parcel) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Parcel not found']);
    exit;
}

// Use real coordinates from the order/parcel if available
if (!empty($order['pickup_lat']) && !empty($order['pickup_lng'])) {
    $from = $order['pickup_lat'] . ',' . $order['pickup_lng'];
} else {
    $from = '28.6139,77.2090'; // Delhi
}
if (!empty($order['delivery_lat']) && !empty($order['delivery_lng'])) {
    $to = $order['delivery_lat'] . ',' . $order['delivery_lng'];
} else {
    $to = '28.7041,77.1025'; // New Delhi
}
$from_coords = $from;
$to_coords = $to;
$distance_km = haversineDistance($from_coords, $to_coords);
$eta_minutes = ($distance_km / $drone_speed_kmh) * 60;

if ($delivery_mode === 'real') {
    $stepsToPickup = 6;
    $stepsToDestination = max(1, ceil($eta_minutes / 0.5)); // 30s per step
    $stepSleep = 30; // 30 seconds per step
    $eta_str = ceil($eta_minutes) . ' min';
} else {
    $stepsToPickup = 6; // 30s to reach pickup (5s per step)
    $stepsToDestination = 24; // 2min to reach destination (5s per step)
    $stepSleep = 3;
    $eta_str = '2 min';
}
$allSteps = $stepsToPickup + $stepsToDestination;

$dronePath = getFakeDronePath($from, $to, $allSteps);

// 2. Assign a fake drone (could be random name/id)
$droneId = 'DRONE-' . rand(100, 999);

// --- NEW: Write initial tracking info to Firebase ---
$firebaseData = [
    'order_id' => $order_id,
    'user_id' => $order['user_id'],
    'drone_id' => $droneId,
    'from_location' => $parcel['from_location'],
    'to_location' => $parcel['to_location'],
    'pickup_coords' => $from,
    'delivery_coords' => $to,
    'current_location' => $dronePath[0],
    'status' => 'Arriving at pickup in ' . ($stepsToPickup * $stepSleep / 60) . ' min',
    'progress' => 0,
    'eta' => $eta_str,
    'tracking_id' => $parcel['id'],
    'created_at' => date('c'), // ISO8601 string, always set on creation
];

firebase_update("drones_tracking/$order_id", $firebaseData);

// Respond immediately to the frontend
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'drone_id' => $droneId,
    'order_id' => $order_id,
    'status' => 'preparing',
]);
flush();

// Launch the simulation worker in the background
$phpPath = PHP_BINDIR . DIRECTORY_SEPARATOR . 'php';
$workerScript = __DIR__ . DIRECTORY_SEPARATOR . 'simulate_drone_worker.php';
$cmd = '"' . $phpPath . '" "' . $workerScript . '" "' . $order_id . '" "' . $delivery_mode . '" "' . $stepsToPickup . '" "' . $stepsToDestination . '" "' . $stepSleep . '" > NUL 2>&1 &';
pclose(popen($cmd, 'r'));
exit;
