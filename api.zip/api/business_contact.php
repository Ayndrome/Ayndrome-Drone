<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

// Allow CORS if needed
define('ALLOW_ORIGIN', '*');
if (defined('ALLOW_ORIGIN')) {
    header('Access-Control-Allow-Origin: ' . ALLOW_ORIGIN);
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

$required = ['first_name', 'last_name', 'business_name', 'email', 'phone', 'message'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => "Missing required field: $field"]);
        exit();
    }
}

try {
    $stmt = $pdo->prepare("INSERT INTO business_contacts (first_name, last_name, business_name, email, phone, message) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $data['first_name'],
        $data['last_name'],
        $data['business_name'],
        $data['email'],
        $data['phone'],
        $data['message']
    ]);

    // Send confirmation email to requester
    $ch = curl_init('http://localhost/ayndrome-api/api/send_business_contact_email.php');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $emailResp = curl_exec($ch);
    curl_close($ch);

    // Send notification email to admin
    $ch2 = curl_init('http://localhost/ayndrome-api/api/send_admin_business_notification.php');
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_POST, true);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($data));
    $adminEmailResp = curl_exec($ch2);
    curl_close($ch2);

    echo json_encode(['success' => true, 'message' => 'Contact request submitted successfully']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
