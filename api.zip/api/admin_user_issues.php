<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query('SELECT ui.*, u.email, u.first_name, u.last_name FROM user_issues ui JOIN users u ON ui.user_id = u.id ORDER BY ui.created_at DESC');
    $issues = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'issues' => $issues]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
