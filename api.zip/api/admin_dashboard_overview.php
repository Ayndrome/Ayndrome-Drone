<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

try {
    // Total users
    $stmtTotal = $pdo->query('SELECT COUNT(*) as total FROM users');
    $totalUsers = $stmtTotal->fetch(PDO::FETCH_ASSOC)['total'];

    // Blocked users
    $stmtBlocked = $pdo->query("SELECT COUNT(*) as blocked FROM users WHERE blocked = 1");
    $blockedUsers = $stmtBlocked->fetch(PDO::FETCH_ASSOC)['blocked'];

    // All users
    $stmtUsers = $pdo->query('SELECT id, first_name, last_name, email FROM users');
    $users = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'total_users' => $totalUsers,
        'blocked_users' => $blockedUsers,
        'users' => $users
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
