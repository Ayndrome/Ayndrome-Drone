<?php
// admin_block_user.php — Admin API to block/unblock a user and set reason
// Usage: POST user_id, blocked (0 or 1), block_reason (optional)

require_once 'db_connect.php'; // assumes $pdo is set

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL); ini_set('display_errors', 1);

// Output to debug file to verify script is running
file_put_contents(__DIR__.'/debug_admin_block_user.log', date('c') . "\nSTARTED\n", FILE_APPEND);

// Simple admin authentication (replace with real auth in production)
session_start();
header('Content-Type: application/json'); // <--- CRITICAL: ensure JSON header
// if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
//     http_response_code(403);
//     echo json_encode(['error' => 'Not authorized']);
//     file_put_contents(__DIR__.'/debug_admin_block_user.log', date('c') . "\nNOT AUTHORIZED\n", FILE_APPEND);
//     exit;
// }

$input = json_decode(file_get_contents('php://input'), true);
$user_id = $input['user_id'] ?? null;
$blocked = isset($input['blocked']) ? (int)$input['blocked'] : null;
$block_reason = $input['block_reason'] ?? null;

if (!$user_id || $blocked === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing user_id or blocked']);
    file_put_contents(__DIR__.'/debug_admin_block_user.log', date('c') . "\nMISSING PARAMS\n", FILE_APPEND);
    exit;
}

try {
    $stmt = $pdo->prepare('UPDATE users SET blocked = ?, block_reason = ? WHERE id = ?');
    $stmt->execute([$blocked, $block_reason, $user_id]);
    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'User not found or no change made']);
        file_put_contents(__DIR__.'/debug_admin_block_user.log', date('c') . "\nNOT FOUND\n", FILE_APPEND);
        exit;
    }
    echo json_encode(['success' => true]);
    file_put_contents(__DIR__.'/debug_admin_block_user.log', date('c') . "\nSUCCESS\n", FILE_APPEND);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
    file_put_contents(__DIR__.'/debug_admin_block_user.log', date('c') . "\nEXCEPTION: " . $e->getMessage() . "\n", FILE_APPEND);
    exit;
}
