<?php
// Start output buffering
ob_start();

// Include required files
require_once 'cors.php';
require_once 'db_connect.php';

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Start session only if not already started (handled in cors.php)
// session_start();

// Function to send JSON response
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['error' => 'Not logged in'], 401);
    }

    // Check if it's a POST request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        send_json_response(['error' => 'Method not allowed'], 405);
    }

    // Get JSON data from request body
    $json_data = file_get_contents('php://input');
    if (!$json_data) {
        send_json_response(['error' => 'No data received'], 400);
    }

    $data = json_decode($json_data, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        send_json_response(['error' => 'Invalid JSON data'], 400);
    }

    // Validate required fields
    $required_fields = ['current_password', 'new_password', 'confirm_password'];
    foreach ($required_fields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            send_json_response(['error' => "Missing required field: $field"], 400);
        }
    }

    // Validate new password and confirm password match
    if ($data['new_password'] !== $data['confirm_password']) {
        send_json_response(['error' => 'New password and confirm password do not match'], 400);
    }

    // Basic password length validation (minimum 6 characters)
    if (strlen($data['new_password']) < 6) {
        send_json_response(['error' => 'Password must be at least 6 characters long'], 400);
    }

    // Get user's current password hash
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = :user_id");
    $stmt->execute([':user_id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        send_json_response(['error' => 'User not found'], 404);
    }

    // Verify current password
    if (!password_verify($data['current_password'], $user['password'])) {
        send_json_response(['error' => 'Current password is incorrect'], 400);
    }

    // Check if new password is different from current password
    if (password_verify($data['new_password'], $user['password'])) {
        send_json_response(['error' => 'New password must be different from current password'], 400);
    }

    // Hash new password
    $new_password_hash = password_hash($data['new_password'], PASSWORD_DEFAULT);

    // Update password in database
    $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE id = :user_id");
    $stmt->execute([
        ':password' => $new_password_hash,
        ':user_id' => $_SESSION['user_id']
    ]);

    if ($stmt->rowCount() === 0) {
        send_json_response(['error' => 'Failed to update password'], 500);
    }

    // Destroy session
    session_destroy();

    send_json_response([
        'success' => true,
        'message' => 'Password changed successfully. Please login again.'
    ]);

} catch (Exception $e) {
    error_log("Error in change_password.php: " . $e->getMessage());
    send_json_response(['error' => 'An internal server error occurred'], 500);
}

// End output buffering
ob_end_flush();
?> 