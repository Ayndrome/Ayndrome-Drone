<?php
// Start output buffering
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Set content type to JSON
header('Content-Type: application/json');

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Not logged in'
    ]);
    exit();
}

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = [
    'pickup_location',
    'dropoff_location',
    'pickup_lat',
    'pickup_lng',
    'dropoff_lat',
    'dropoff_lng',
    'scheduled_date',
    'scheduled_time',
    'price',
    'distance',
    'duration',
    'payment_method',
    'package_details'
];

foreach ($requiredFields as $field) {
    if (!isset($data[$field])) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => "Missing required field: $field"
        ]);
        exit();
    }
}

try {
    // Begin transaction
    $conn->begin_transaction();

    // Insert into rides table
    $stmt = $conn->prepare("
        INSERT INTO rides (
            user_id, pickup_location, dropoff_location,
            pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
            scheduled_date, scheduled_time, price, distance,
            duration, payment_method, package_details
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "isssddddssddds",
        $_SESSION['user_id'],
        $data['pickup_location'],
        $data['dropoff_location'],
        $data['pickup_lat'],
        $data['pickup_lng'],
        $data['dropoff_lat'],
        $data['dropoff_lng'],
        $data['scheduled_date'],
        $data['scheduled_time'],
        $data['price'],
        $data['distance'],
        $data['duration'],
        $data['payment_method'],
        json_encode($data['package_details'])
    );

    if (!$stmt->execute()) {
        throw new Exception("Error saving ride: " . $stmt->error);
    }

    $rideId = $conn->insert_id;

    // Generate tracking ID
    $trackingId = 'DR-' . str_pad($rideId, 6, '0', STR_PAD_LEFT);

    // Insert into delivery_history
    $stmt = $conn->prepare("
        INSERT INTO delivery_history (
            ride_id, user_id, status, tracking_id,
            from_location, to_location, items, cost
        ) VALUES (?, ?, 'pending', ?, ?, ?, ?, ?)
    ");

    $items = isset($data['package_details']['description']) ? $data['package_details']['description'] : 'Package';
    $stmt->bind_param(
        "iissssd",
        $rideId,
        $_SESSION['user_id'],
        $trackingId,
        $data['pickup_location'],
        $data['dropoff_location'],
        $items,
        $data['price']
    );

    if (!$stmt->execute()) {
        throw new Exception("Error saving delivery history: " . $stmt->error);
    }

    // Insert into track_parcels
    $stmt = $conn->prepare("
        INSERT INTO track_parcels (
            ride_id, tracking_id, status, progress
        ) VALUES (?, ?, 'processing', 0)
    ");

    $stmt->bind_param("is", $rideId, $trackingId);

    if (!$stmt->execute()) {
        throw new Exception("Error saving tracking information: " . $stmt->error);
    }

    // Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Ride booked successfully',
        'ride_id' => $rideId,
        'tracking_id' => $trackingId
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    
    error_log("Error in save_ride.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred while saving the ride. Please try again.'
    ]);
}

// End output buffering and flush
ob_end_flush();
?> 