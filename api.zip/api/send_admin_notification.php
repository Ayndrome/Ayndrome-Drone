<?php
require_once 'db_connect.php';
require_once 'create_activity.php';
header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$user_ids = $data['user_ids'] ?? [];
$title = $data['title'] ?? '';
$description = $data['description'] ?? '';
$type = $data['type'] ?? 'info';
$status = $data['status'] ?? 'info';

if (!$user_ids || !$title || !$description) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

$success = true;
foreach ($user_ids as $user_id) {
    $result = createUserActivity($pdo, $user_id, $title, $description, $type, $status);
    if (!$result) $success = false;
}

if ($success) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'One or more notifications failed']);
}
