<?php
// Start output buffering to prevent any output before headers
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Include utility functions
require_once 'utils.php';

// Set timezone
date_default_timezone_set('Asia/Kolkata');

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if it's a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

try {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['success' => false, 'error' => 'Not logged in'], 401);
    }

    // Get user activity
    $stmt = $pdo->prepare("SELECT * FROM users_activity WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $activity = $stmt->fetchAll(PDO::FETCH_ASSOC);

    send_json_response([
        'success' => true,
        'activity' => $activity
    ]);

} catch (Exception $e) {
    error_log("Error in get_user_activity.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'An error occurred'], 500);
}

// End output buffering and flush
ob_end_flush();
?> 