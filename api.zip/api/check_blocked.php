<?php
// check_blocked.php — Returns blocked status and reason for the current user
session_start();
header('Content-Type: application/json');

// Example: replace with your actual DB connection
require_once 'db_connect.php'; // assumes $pdo is set

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    echo json_encode(['blocked' => false, 'block_reason' => '']);
    exit;
}

$stmt = $pdo->prepare('SELECT blocked, block_reason FROM users WHERE id = ?');
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && $user['blocked']) {
    echo json_encode([
        'blocked' => true,
        'block_reason' => $user['block_reason'] ?? 'No reason specified.'
    ]);
} else {
    echo json_encode(['blocked' => false, 'block_reason' => '']);
}
