<?php
// Start output buffering
ob_start();

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Register error handler
function errorHandler($errno, $errstr, $errfile, $errline) {
    $error = [
        'type' => $errno,
        'message' => $errstr,
        'file' => $errfile,
        'line' => $errline
    ];
    error_log(json_encode($error));
    return false;
}
set_error_handler('errorHandler');

// Register exception handler
function exceptionHandler($exception) {
    error_log(json_encode([
        'type' => 'Exception',
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString()
    ]));
    http_response_code(500);
    echo json_encode(['error' => 'An internal server error occurred']);
    exit;
}
set_exception_handler('exceptionHandler');

// Include required files
require_once 'cors.php';
require_once 'db_connect.php';
require_once 'create_activity.php';
require_once 'send_email.php';

// Set content type to JSON
header('Content-Type: application/json');

// Custom error logging
function custom_log($message) {
    $log_file = __DIR__ . '/order_creation.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[$timestamp] $message" . PHP_EOL;
    file_put_contents($log_file, $log_message, FILE_APPEND);
}

// Function to send JSON response
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit;
}

// Handle errors
function handle_error($error_message, $status_code = 500) {
    custom_log("Error: $error_message");
    send_json_response(['error' => $error_message], $status_code);
}

// Start session
session_start();

// Debug session
custom_log("Session data: " . print_r($_SESSION, true));
custom_log("Cookie data: " . print_r($_COOKIE, true));

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    handle_error("User not logged in", 401);
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get JSON data from request body
        $json_data = file_get_contents('php://input');
        custom_log("Received JSON data: " . $json_data);
        
        if (!$json_data) {
            handle_error("No data received", 400);
        }

        $data = json_decode($json_data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            handle_error("Invalid JSON data: " . json_last_error_msg(), 400);
        }

        // Validate required fields
        $required_fields = [
            'pickup_address',
            'delivery_address',
            'pickup_lat',
            'pickup_lng',
            'delivery_lat',
            'delivery_lng',
            'scheduled_date',
            'scheduled_time',
            'package_weight',
            'package_dimensions',
            'total_amount'
        ];

        foreach ($required_fields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                handle_error("Missing required field: $field", 400);
            }
        }

        // Start transaction
        $pdo->beginTransaction();

        // Insert into users_orders
        $query = "
            INSERT INTO users_orders (
                user_id,
                order_id,
                pickup_address,
                delivery_address,
                pickup_lat,
                pickup_lng,
                delivery_lat,
                delivery_lng,
                scheduled_date,
                scheduled_time,
                package_weight,
                package_dimensions,
                total_amount,
                order_status,
                payment_status,
                created_at
            ) VALUES (
                :user_id,
                :order_id,
                :pickup_address,
                :delivery_address,
                :pickup_lat,
                :pickup_lng,
                :delivery_lat,
                :delivery_lng,
                :scheduled_date,
                :scheduled_time,
                :package_weight,
                :package_dimensions,
                :total_amount,
                :order_status,
                :payment_status,
                NOW()
            )
        ";

        $stmt = $pdo->prepare($query);
        if (!$stmt) {
            throw new Exception('Failed to prepare query');
        }

        $orderId = 'DR-' . strtoupper(uniqid());
        $orderStatus = 'pending';
        $paymentStatus = 'pending';

        $params = [
            ':user_id' => $_SESSION['user_id'],
            ':order_id' => $orderId,
            ':pickup_address' => $data['pickup_address'],
            ':delivery_address' => $data['delivery_address'],
            ':pickup_lat' => $data['pickup_lat'],
            ':pickup_lng' => $data['pickup_lng'],
            ':delivery_lat' => $data['delivery_lat'],
            ':delivery_lng' => $data['delivery_lng'],
            ':scheduled_date' => $data['scheduled_date'],
            ':scheduled_time' => $data['scheduled_time'],
            ':package_weight' => $data['package_weight'],
            ':package_dimensions' => $data['package_dimensions'],
            ':total_amount' => $data['total_amount'],
            ':order_status' => $orderStatus,
            ':payment_status' => $paymentStatus
        ];

        custom_log("Executing query with params: " . print_r($params, true));

        $stmt->execute($params);

        if ($stmt->errorCode() !== '00000') {
            throw new Exception('Failed to execute query: ' . implode(' ', $stmt->errorInfo()));
        }

        $orderInsertId = $pdo->lastInsertId();

        // Insert into track_parcels if order_status is 'pending'
        if ($orderStatus === 'pending') {
            $trackingId = $orderId; 
            $insertTrackParcel = $pdo->prepare("
                INSERT INTO track_parcels (
                    order_id,
                    tracking_id,
                    user_id,
                    status,
                    progress,
                    eta,
                    current_location,
                    last_updated,
                    from_location,
                    to_location,
                    items,
                    cost,
                    scheduled_date,
                    scheduled_time
                ) VALUES (
                    :order_id,
                    :tracking_id,
                    :user_id,
                    :status,
                    0,
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP,
                    :from_location,
                    :to_location,
                    :items,
                    :cost,
                    :scheduled_date,
                    :scheduled_time
                )
            ");
            if ($insertTrackParcel) {
                $insertTrackParcel->execute([
                    ':order_id' => $orderId, 
                    ':tracking_id' => $trackingId, 
                    ':user_id' => $_SESSION['user_id'],
                    ':status' => $orderStatus,
                    ':from_location' => $data['pickup_address'],
                    ':to_location' => $data['delivery_address'],
                    ':items' => $data['package_dimensions'],
                    ':cost' => $data['total_amount'],
                    ':scheduled_date' => $data['scheduled_date'],
                    ':scheduled_time' => $data['scheduled_time']
                ]);
            }
        }

        // Create activity for new order
        createUserActivity(
            $pdo,
            $_SESSION['user_id'],
            'New Delivery Scheduled',
            "Your delivery (#{$orderId}) has been scheduled for {$data['scheduled_date']} at {$data['scheduled_time']}",
            'delivery',
            'pending',
            $orderInsertId
        );

        // Get user details for email
        $user_stmt = $pdo->prepare("SELECT email, first_name FROM users WHERE id = :user_id");
        $user_stmt->execute([':user_id' => $_SESSION['user_id']]);
        $user = $user_stmt->fetch(PDO::FETCH_ASSOC);

        // Prepare order details for email
        $orderDetails = [
            'order_id' => $orderId,
            'pickup_address' => $data['pickup_address'],
            'delivery_address' => $data['delivery_address'],
            'scheduled_date' => $data['scheduled_date'],
            'scheduled_time' => $data['scheduled_time'],
            'package_dimensions' => $data['package_dimensions'],
            'total_amount' => $data['total_amount'],
            'status' => 'pending'
        ];

        // Send confirmation email
        $emailSent = sendOrderConfirmationEmail($user['email'], $user['first_name'], $orderDetails);

        // Commit transaction
        $pdo->commit();

        // The background worker trigger has been removed. The polling_worker.php script now handles all new orders automatically.
        send_json_response([
            'success' => true,
            'message' => 'Order created successfully',
            'order_id' => $orderId,
            'email_sent' => $emailSent
        ]);

    } catch (Exception $e) {
        // Rollback transaction on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        custom_log("Error in create_order.php: " . $e->getMessage());
        custom_log("Stack trace: " . $e->getTraceAsString());
        
        handle_error($e->getMessage());
    }
} else {
    handle_error('Method not allowed', 405);
}

// End output buffering
ob_end_flush();
?>