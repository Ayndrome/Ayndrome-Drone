<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define log file paths
$phpLogPath = 'C:/xampp/php/logs/php_error.log';
$apacheLogPath = 'C:/xampp/apache/logs/error.log';

echo "<h2>Error Logs</h2>";

// Check PHP error log
echo "<h3>PHP Error Log</h3>";
if (file_exists($phpLogPath)) {
    $phpLog = file_get_contents($phpLogPath);
    if ($phpLog) {
        echo "<pre>" . htmlspecialchars($phpLog) . "</pre>";
    } else {
        echo "PHP error log is empty";
    }
} else {
    echo "PHP error log file not found at: $phpLogPath";
}

// Check Apache error log
echo "<h3>Apache Error Log</h3>";
if (file_exists($apacheLogPath)) {
    $apacheLog = file_get_contents($apacheLogPath);
    if ($apacheLog) {
        echo "<pre>" . htmlspecialchars($apacheLog) . "</pre>";
    } else {
        echo "Apache error log is empty";
    }
} else {
    echo "Apache error log file not found at: $apacheLogPath";
}

// Also show recent PHP errors
echo "<h3>Recent PHP Errors</h3>";
echo "<pre>";
error_log("Test error message");
echo "</pre>";

// Show PHP configuration
echo "<h3>PHP Configuration</h3>";
echo "<pre>";
echo "error_reporting: " . ini_get('error_reporting') . "\n";
echo "display_errors: " . ini_get('display_errors') . "\n";
echo "log_errors: " . ini_get('log_errors') . "\n";
echo "error_log: " . ini_get('error_log') . "\n";
echo "</pre>";
?> 