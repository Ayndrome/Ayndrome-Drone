<?php
require_once 'cors.php';
require_once 'db_connect.php';
require_once 'utils.php';

date_default_timezone_set('Asia/Kolkata');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$json = file_get_contents('php://input');
$data = json_decode($json, true);


$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    send_json_response(['success' => false, 'error' => 'User not logged in'], 401);
}

$description = trim($data['description'] ?? '');
$order_id = trim($data['order_id'] ?? '');

if (!$description) {
    send_json_response(['success' => false, 'error' => 'Description is required'], 400);
}

try {
    $stmt = $pdo->prepare("INSERT INTO user_issues (user_id, order_id, description, created_at) VALUES (:user_id, :order_id, :description, NOW())");
    $ok = $stmt->execute([
        ':user_id' => $user_id,
        ':order_id' => $order_id !== '' ? $order_id : null,
        ':description' => $description
    ]);
    if (!$ok) {
        error_log('report_issue.php SQL error: ' . json_encode($stmt->errorInfo()));
        send_json_response(['success' => false, 'error' => 'SQL error', 'debug' => $stmt->errorInfo()], 500);
    }
    send_json_response(['success' => true, 'message' => 'Issue reported successfully']);
} catch (Exception $e) {
    error_log('Error in report_issue.php: ' . $e->getMessage());
    send_json_response(['success' => false, 'error' => 'Failed to report issue', 'debug' => $e->getMessage()], 500);
}
?>
