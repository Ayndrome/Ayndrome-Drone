<?php
require '../vendor/autoload.php';
require_once 'send_email.php';
require_once 'db_connect.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendBusinessContactEmail($contact) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'shashanksaket9@gmail.com';
        $mail->Password = 'goou gtms okin wdwx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('shashanksaket9@gmail.com', 'Ayndrome Business');
        $mail->addAddress($contact['email'], $contact['first_name'] . ' ' . $contact['last_name']);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Thank you for contacting Ayndrome Business';

        // Modern, simple HTML email body
        $body = "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e0e0e0; border-radius: 8px; padding: 32px 24px;'>
            <h2 style='color: #222; margin-bottom: 16px;'>Thank you for contacting Ayndrome Business</h2>
            <p style='font-size: 1rem; color: #444; margin-bottom: 24px;'>Hi <b>" . htmlspecialchars($contact['first_name']) . "</b>,<br><br>
            We have received your request and our team will be in touch with you soon.<br><br>
            <b>Here are the details you submitted:</b></p>
            <table style='width: 100%; font-size: 1rem; color: #444; border-collapse: collapse;'>
                <tr><td style='padding: 6px 0;'><b>Name:</b></td><td>" . htmlspecialchars($contact['first_name'] . ' ' . $contact['last_name']) . "</td></tr>
                <tr><td style='padding: 6px 0;'><b>Business:</b></td><td>" . htmlspecialchars($contact['business_name']) . "</td></tr>
                <tr><td style='padding: 6px 0;'><b>Email:</b></td><td>" . htmlspecialchars($contact['email']) . "</td></tr>
                <tr><td style='padding: 6px 0;'><b>Phone:</b></td><td>" . htmlspecialchars($contact['phone']) . "</td></tr>
                <tr><td style='padding: 6px 0; vertical-align: top;'><b>Message:</b></td><td>" . nl2br(htmlspecialchars($contact['message'])) . "</td></tr>
            </table>
            <p style='font-size: 0.95rem; color: #666; margin-top: 32px;'>Best regards,<br>Ayndrome Business Team</p>
        </div>";

        $mail->Body = $body;
        $mail->AltBody = "Thank you for contacting Ayndrome Business. We have received your request and will be in touch soon.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Business contact email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        return false;
    }
}

// API endpoint logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $required = ['first_name', 'last_name', 'business_name', 'email', 'phone', 'message'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => "Missing required field: $field"]);
            exit();
        }
    }
    if (sendBusinessContactEmail($data)) {
        echo json_encode(['success' => true, 'message' => 'Confirmation email sent.']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to send confirmation email.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
}
