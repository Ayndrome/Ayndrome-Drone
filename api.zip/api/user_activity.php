<?php
// Start output buffering
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Start session
session_start();

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Not logged in');
    }

    // Handle different HTTP methods
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            // Get user activities
            $query = "
                SELECT 
                    ua.id,
                    ua.title,
                    ua.description,
                    ua.status,
                    ua.type,
                    ua.created_at as date,
                    uo.order_id as tracking_id
                FROM users_activity ua
                LEFT JOIN users_orders uo ON ua.order_id = uo.id
                WHERE ua.user_id = :user_id
                ORDER BY ua.created_at DESC
            ";
            
            $stmt = $pdo->prepare($query);
            if (!$stmt) {
                throw new Exception('Failed to prepare query: ' . implode(' ', $pdo->errorInfo()));
            }

            $stmt->execute([':user_id' => $_SESSION['user_id']]);
            if ($stmt->errorCode() !== '00000') {
                throw new Exception('Failed to execute query: ' . implode(' ', $stmt->errorInfo()));
            }

            $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format the activities
            $formattedActivities = array_map(function($activity) {
                return [
                    'id' => $activity['id'],
                    'title' => $activity['title'],
                    'description' => $activity['description'],
                    'status' => $activity['status'],
                    'type' => $activity['type'],
                    'date' => $activity['date'],
                    'tracking_id' => $activity['tracking_id']
                ];
            }, $activities);
            
            echo json_encode([
                'success' => true,
                'activities' => $formattedActivities
            ]);
            break;
            
        case 'POST':
            // Create new activity
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['title']) || !isset($data['description']) || !isset($data['type'])) {
                throw new Exception('Title, description, and type are required');
            }
            
            $query = "
                INSERT INTO users_activity (
                    user_id,
                    order_id,
                    title,
                    description,
                    status,
                    type
                ) VALUES (
                    :user_id,
                    :order_id,
                    :title,
                    :description,
                    :status,
                    :type
                )
            ";
            
            $stmt = $pdo->prepare($query);
            if (!$stmt) {
                throw new Exception('Failed to prepare query: ' . implode(' ', $pdo->errorInfo()));
            }
            
            $stmt->execute([
                ':user_id' => $_SESSION['user_id'],
                ':order_id' => $data['order_id'] ?? null,
                ':title' => $data['title'],
                ':description' => $data['description'],
                ':status' => $data['status'] ?? 'pending',
                ':type' => $data['type']
            ]);
            
            if ($stmt->errorCode() !== '00000') {
                throw new Exception('Failed to execute query: ' . implode(' ', $stmt->errorInfo()));
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Activity created successfully',
                'activity_id' => $pdo->lastInsertId()
            ]);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    error_log("Error in user_activity.php: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// End output buffering and flush
ob_end_flush();
?> 