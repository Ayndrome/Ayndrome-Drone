<?php
require_once 'db_connect.php';

try {
    $sql = "CREATE TABLE IF NOT EXISTS users_orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        order_id VARCHAR(20) NOT NULL UNIQUE,
        pickup_address TEXT NOT NULL,
        delivery_address TEXT NOT NULL,
        pickup_lat DECIMAL(10, 8) NOT NULL,
        pickup_lng DECIMAL(11, 8) NOT NULL,
        delivery_lat DECIMAL(10, 8) NOT NULL,
        delivery_lng DECIMAL(11, 8) NOT NULL,
        scheduled_date DATE NOT NULL,
        scheduled_time TIME NOT NULL,
        package_weight DECIMAL(10, 2) NOT NULL,
        package_dimensions VARCHAR(50) NOT NULL,
        package_description TEXT,
        payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
        order_status ENUM('pending', 'accepted', 'in_progress', 'delivered', 'cancelled') DEFAULT 'pending',
        total_amount DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Table users_orders created successfully";
    } else {
        throw new Exception("Error creating table: " . $conn->error);
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

$conn->close();
?> 