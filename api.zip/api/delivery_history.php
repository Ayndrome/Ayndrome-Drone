<?php
// Start output buffering
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';
require_once 'create_activity.php';
require_once 'utils.php';

// Enable error reporting but don't display errors
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Set content type to JSON
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if it's a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

try {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        send_json_response(['success' => false, 'error' => 'Not logged in'], 401);
    }

    // Get query parameters
    $timeFilter = isset($_GET['time_filter']) ? $_GET['time_filter'] : 'all';
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    // Build query based on time filter
    $query = "SELECT * FROM users_orders WHERE user_id = :user_id";
    $params = [':user_id' => $_SESSION['user_id']];

    if ($timeFilter !== 'all') {
        $dateFilter = '';
        switch ($timeFilter) {
            case 'today':
                $dateFilter = "DATE(scheduled_date) = CURDATE()";
                break;
            case 'week':
                $dateFilter = "scheduled_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
                break;
            case 'month':
                $dateFilter = "scheduled_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
                break;
        }
        $query .= " AND $dateFilter";
    }

    if (!empty($search)) {
        $query .= " AND (order_id LIKE :search OR pickup_address LIKE :search OR delivery_address LIKE :search)";
        $params[':search'] = "%$search%";
    }

    $query .= " ORDER BY created_at DESC";

    $stmt = $pdo->prepare($query);
    if (!$stmt) {
        throw new Exception('Failed to prepare query');
    }

    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format the response
    $formattedOrders = array_map(function($order) {
        return [
            'id' => $order['id'],
            'tracking_id' => $order['order_id'],
            'from_location' => $order['pickup_address'],
            'to_location' => $order['delivery_address'],
            'items' => $order['package_dimensions'],
            'cost' => number_format($order['total_amount'], 2),
            'status' => $order['order_status'],
            'created_at' => $order['created_at'],
            'scheduled_date' => $order['scheduled_date'],
            'scheduled_time' => $order['scheduled_time']
        ];
    }, $orders);

    // Create activity for viewing delivery history
    // Removed as per user request: do not log this action anymore
    // createUserActivity(
    //     $pdo,
    //     $_SESSION['user_id'],
    //     'Viewed Delivery History',
    //     'User viewed their delivery history',
    //     'history',
    //     'completed',
    //     null
    // );

    send_json_response([
        'success' => true,
        'delivery_history' => $formattedOrders
    ]);

} catch (Exception $e) {
    error_log("Error in delivery_history.php: " . $e->getMessage());
    send_json_response(['success' => false, 'error' => $e->getMessage()], 500);
}

// End output buffering and flush
ob_end_flush();
?> 