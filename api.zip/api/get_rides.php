<?php
// Start output buffering to prevent any output before headers
ob_start();

// Include CORS configuration
require_once 'cors.php';

// Include database connection
require_once 'db_connect.php';

// Set content type to JSON
header('Content-Type: application/json');

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Not logged in'
    ]);
    exit();
}

try {
    // Check if database connection is valid
    if (!$conn || $conn->connect_error) {
        error_log("Database connection error: " . ($conn ? $conn->connect_error : "Connection is null"));
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Database connection error'
        ]);
        exit();
    }
    
    // Check if rides table exists
    $tableCheck = $conn->query("SHOW TABLES LIKE 'rides'");
    if ($tableCheck->num_rows === 0) {
        // Create rides table if it doesn't exist
        $createTable = "CREATE TABLE IF NOT EXISTS rides (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            user_id INT(11) NOT NULL,
            pickup_location VARCHAR(255) NOT NULL,
            dropoff_location VARCHAR(255) NOT NULL,
            pickup_time DATETIME NOT NULL,
            status ENUM('pending', 'accepted', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )";
        
        if ($conn->query($createTable) !== TRUE) {
            error_log("Error creating rides table: " . $conn->error);
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Database configuration error'
            ]);
            exit();
        }
        
        // Return empty rides array since the table was just created
        echo json_encode([
            'success' => true,
            'rides' => []
        ]);
        exit();
    }
    
    // Get user's rides with detailed information
    $query = "
        SELECT 
            r.id,
            r.pickup_location,
            r.dropoff_location,
            r.pickup_lat,
            r.pickup_lng,
            r.dropoff_lat,
            r.dropoff_lng,
            r.status,
            r.created_at,
            r.scheduled_date,
            r.scheduled_time,
            r.completed_at,
            r.price,
            r.distance,
            r.duration,
            r.payment_method,
            r.package_details,
            dh.tracking_id,
            dh.items,
            tp.progress,
            tp.eta,
            tp.current_location
        FROM rides r
        LEFT JOIN delivery_history dh ON r.id = dh.ride_id
        LEFT JOIN track_parcels tp ON dh.tracking_id = tp.tracking_id
        WHERE r.user_id = ?
        ORDER BY r.created_at DESC
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $rides = [];
    while ($row = $result->fetch_assoc()) {
        // Format the data
        $ride = [
            'id' => $row['id'],
            'pickup' => [
                'location' => $row['pickup_location'],
                'coordinates' => [
                    'lat' => $row['pickup_lat'],
                    'lng' => $row['pickup_lng']
                ]
            ],
            'dropoff' => [
                'location' => $row['dropoff_location'],
                'coordinates' => [
                    'lat' => $row['dropoff_lat'],
                    'lng' => $row['dropoff_lng']
                ]
            ],
            'status' => $row['status'],
            'scheduled' => [
                'date' => $row['scheduled_date'],
                'time' => $row['scheduled_time']
            ],
            'created_at' => $row['created_at'],
            'completed_at' => $row['completed_at'],
            'price' => $row['price'],
            'distance' => $row['distance'],
            'duration' => $row['duration'],
            'payment_method' => $row['payment_method'],
            'package_details' => json_decode($row['package_details'], true),
            'tracking' => [
                'id' => $row['tracking_id'],
                'items' => $row['items'],
                'progress' => $row['progress'],
                'eta' => $row['eta'],
                'current_location' => $row['current_location']
            ]
        ];
        
        $rides[] = $ride;
    }
    
    echo json_encode([
        'success' => true,
        'rides' => $rides
    ]);
    
} catch (Exception $e) {
    // Log the error (but don't expose it to the client)
    error_log("Error in get_rides.php: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred while fetching rides. Please try again.'
    ]);
}

// End output buffering and flush
ob_end_flush();
?> 